/**
 ****************************************************************************************
 *
 * @file user_uart_gtl.c
 *
 * @brief ROM overridden functions for propriety GTL protocol source code.
 *
 * Copyright (C) 2012-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup APP
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "rwip_config.h"                    // SW configuration
#include "user_periph_setup.h"             // SW configuration
#include "arch_api.h"
#include "user_config.h"
#include "arch_api.h"
#include "user_uart_gtl.h"
#include "wkupct_quadec.h"
#include "rwip.h"
#include "gtl_4w_uart_wake_up.h"

/*
 * GLOBAL VARIABLES
 ****************************************************************************************
*/
bool ext_wake_up_req    __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
*/
extern void uart_write_func(uint8_t *bufptr, uint32_t size, void (*callback) (uint8_t));
extern void uart_flow_on_func(void);
extern void gtl_eif_init_func(void);

/**
 ****************************************************************************************
 * @brief Introduces a variable microsend delay for use with ADC peripheral.
 * @param[in] nof_us Number of microseconds to delay
 ****************************************************************************************
 */
static void usDelay(uint32_t nof_us)
{
    while( nof_us-- ){
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
    }
}

static void custom_uart_flow_on(void)
{
    uart_flow_on_func();
}

/**
 ****************************************************************************************
 * @brief Performs the wake up sequence for waking up the external processor
 ****************************************************************************************
 */
static void perform_wakeup_seq(void)
{
    if(!GPIO_GetPinStatus(UART1_RTSN_PORT, UART1_RTSN_PIN))
    {
        SetWord32(UART_MCR_REG, UART_AFCE);     // Disable AFCE and set UART_RTS to 0 to de-assert the RTS
        usDelay(50);
    }
    custom_uart_flow_on();              // Re-enable the AFCE and set UART_RTS to high to assert the RTS
}

arch_main_loop_callback_ret_t poll_external_wake_up_req(void)
{
    if(ext_wake_up_req)
    {
        perform_wakeup_seq();           // Perform a wake up sequence if necessary (ext device might have gone to sleep) and flow on.
        ext_wake_up_req = false;
        return KEEP_POWERED;
    }
    return GOTO_SLEEP;
}

#if 0
sleep_mode_t user_validate_sleep(sleep_mode_t sleep_mode)
{
    if (ext_wake_up_req !=0)
    {
        return mode_active;
    }
    else
    {
        return sleep_mode;
    }
}
#endif

void gtl_eif_init_func_custom(void)
{
    custom_uart_flow_on();
    
    gtl_eif_init_func();
}

void uart_flow_on_func_custom(void)
{
    /* 
    * Flow on is executed as soon as the device is awake and ready to transmit or receive
    * This jump_table function should only be executed when there is a wake up request from the peer device
    * in order to indicate to the peer that data need to be send
    */    
    // ----> Enable AFCE
    SetWord32(UART_MCR_REG, UART_AFCE);  
}

void uart_write_func_custom(uint8_t *bufptr, uint32_t size,void (*callback) (uint8_t))
{
    /* When uart is initialized the AFCE remains disabled, the AFCE is enabled when flow_on is invoked */
    /* UART is enabled during the periph_init in every wake up from the resume from sleep hook */

    /* Perform the write regardless the state of the CTS, 
    * the UART will send out the data as soon as the CTS goes LOW
    */
    uart_write_func(bufptr, size, callback);
    
   /* Issue a flow on
    * The transition of RTS from HIGH to LOW is also used as a wake up signal to the other side
    * this should occur regardless if the other side is available or not
    */
    perform_wakeup_seq();
}

/***************************************************************************************/
/************************* Custom external wake up implementation **********************/
/********* Consider when the wakeup controller should be enabled or disabled ***********/
/*************** Enabled if sleeping or when flow_off is true **************************/
/********************** Disabled when flow off is false ********************************/
/***************************************************************************************/

/**
 ****************************************************************************************
 * @brief Callback function of the wakeup controller
 ****************************************************************************************
 */
static void ext_wakeup_cb(void)
{
#if !defined (__DA14531__)
    if (GetBits16(SYS_STAT_REG, PER_IS_DOWN))
    {
        // Return GPIO functionality from external wakeup GPIO
        if (DEVELOPMENT_DEBUG)
            GPIO_reservations();
        set_pad_functions();
    }
#endif
    //SetBits32(GP_CONTROL_REG, BLE_WAKEUP_REQ, 1);
    arch_ble_force_wakeup();
    /* Indicate that this is a wake up request from the external processor */
    ext_wake_up_req = true;
    
    ext_wakeup_enable_custom(UART1_CTSN_PORT, UART1_CTSN_PIN, 0);
}

void ext_wakeup_enable_custom(uint32_t port, uint32_t pin, uint8_t polarity)
{
    wkupct_register_callback(ext_wakeup_cb);

    wkupct_enable_irq(WKUPCT_PIN_SELECT((GPIO_PORT) port, (GPIO_PIN) pin), // Select pin
                      WKUPCT_PIN_POLARITY((GPIO_PORT) port, (GPIO_PIN) pin, (polarity == 0) ? WKUPCT_PIN_POLARITY_LOW : WKUPCT_PIN_POLARITY_HIGH), // Polarity
                      1, // 1 event
                      0); // debouncing time = 0
}

void ext_wakeup_disable_custom(void)
{
    wkupct_disable_irq();
}

/// @} APP
