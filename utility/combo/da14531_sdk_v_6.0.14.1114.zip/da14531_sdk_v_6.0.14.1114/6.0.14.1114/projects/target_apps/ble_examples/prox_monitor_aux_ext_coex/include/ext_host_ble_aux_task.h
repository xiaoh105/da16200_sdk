/**
 ****************************************************************************************
 *
 * @file ext_host_ble_aux_task.h
 *
 * @brief Header file to support the APP_GET_FW_VERSION message.
 *
 * Copyright (c) 2015-2018 Dialog Semiconductor. All rights reserved.
 *
 * This software ("Software") is owned by Dialog Semiconductor.
 *
 * By using this Software you agree that Dialog Semiconductor retains all
 * intellectual property and proprietary rights in and to this Software and any
 * use, reproduction, disclosure or distribution of the Software without express
 * written permission or a license agreement from Dialog Semiconductor is
 * strictly prohibited. This Software is solely for use on or in conjunction
 * with Dialog Semiconductor products.
 *
 * EXCEPT AS OTHERWISE PROVIDED IN A LICENSE AGREEMENT BETWEEN THE PARTIES, THE
 * SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. EXCEPT AS OTHERWISE
 * PROVIDED IN A LICENSE AGREEMENT BETWEEN THE PARTIES, IN NO EVENT SHALL
 * DIALOG SEMICONDUCTOR BE LIABLE FOR ANY DIRECT, SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF
 * USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THE SOFTWARE.
 *
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */
 
 
#ifndef EXT_HOST_BLE_AUX_TASK_H_
#define EXT_HOST_BLE_AUX_TASK_H_ 


#define EXT_HOST_BLE_AUX_IDX_MAX        (1)
#define APP_FW_VERSION_STRING_MAX_LENGTH (24)
// RESER detection parameters
#define RESET_DUMP_LENGTH_IN_BYTES (60)

// APP_DBG_CONFIG related parameters
#define CUSTOM_GTL_OVER_I2C_PARAM_LEN_MIN_VALID 64
#define CUSTOM_GTL_OVER_I2C_PARAM_LEN_MAX_VALID 1024    // This value needs further investigation
#define APP_DBG_CONFIG_NONE (0)
#define APP_DBG_CONFIG_STATS (1<<0)
#define APP_DBG_CONFIG_MSG_MAX_LEN (1<<1)
#define APP_DBG_CONFIG_I2C_TIMEOUT (1<<2)
#define APP_DBG_CONFIG_GTL_CON_ERR_IND (1<<3)

// common
#define WIFI_WAKE_UP_VIA_UART_RTS
#define __FORCE_RESET_ON_EXCEPTION__

#define __GTL_UART_115200__
#define __DISABLE_JTAG_SWD_PINS_IN_BLE__

#include <stdint.h>
#include "gtl_env.h"

typedef enum {
    GTL_LOG_MESSAGE_METADATA_ORIGIN_UNKNOWN = 0x00,
    GTL_LOG_MESSAGE_METADATA_ORIGIN_BLE_APP = 0xEE,
    GTL_LOG_MESSAGE_METADATA_ORIGIN_EXT_HOST = 0xFF,
} message_metadata_origin_t;

/// Possible states of the EXT_HOST_BLE_AUX task
enum
{
    ///Disabled state
    EXT_HOST_BLE_AUX_DISABLED,
    ///Idle state
    EXT_HOST_BLE_AUX_IDLE,
    ///Connected state
    EXT_HOST_BLE_AUX_CONNECTED,

    ///Number of defined states.
    EXT_HOST_BLE_AUX_STATE_MAX
};

#define KE_FIRST_MSG(task) ((ke_msg_id_t)((task) << 8))
typedef enum {
    APP_GEN_RAND_REQ = KE_FIRST_MSG(TASK_ID_EXT_HOST_BLE_AUX) + 1,  // 0xA000 + 1
    APP_GEN_RAND_RSP,       //2 
    APP_STATUS_IND,         //3
    APP_SET_TXPOWER,        //4
    APP_SET_TXPOWER_CFM,    //5
    APP_SET_REG_VALUE,      //6
    APP_SET_REG_VALUE_CFM,  //7
    APP_GET_REG_VALUE,      //8
    APP_GET_REG_VALUE_RSP,  //9
    APP_STATS_IND,          //10 0x0A
    APP_DEV_RESET_IND,      //11 0x0B
    APP_MTU_CHANGED_IND,    //12 0x0C
    APP_DBG_CONFIG_CMD,     //13 0x0D
    //APP_STATS_CONFIG_CMD, 
    //APP_CRC_ERROR_IND,	//missing
    APP_ECHO,               //14 0x0E
    APP_GET_FW_VERSION,     //15 0x0F
    APP_FW_VERSION_IND,     //16 0x10
    APP_GET_DEBUG_DUMP,     //17 0x11
    APP_GET_DEBUG_DUMP_RSP, //18 0x12
    APP_GTL_COM_ERR_IND,    //19 0x13
    
    APP_SVC_CHANGED_CFG_CMD = KE_FIRST_MSG(TASK_EXT_HOST_BLE_AUX) + 38,
    APP_SVC_CHANGED_CFG_CFM = KE_FIRST_MSG(TASK_EXT_HOST_BLE_AUX) + 39,  

    APP_STATS_TIMER_ID = KE_FIRST_MSG(TASK_EXT_HOST_BLE_AUX) + 40,
    APP_HEARTBEAT_TIMER_ID,

	APP_BLE_SW_RESET,
	
    APP_GAS_LEAK_SENSOR_START,
    APP_GAS_LEAK_SENSOR_START_CFM,
    APP_GAS_LEAK_SENSOR_STOP,
    APP_GAS_LEAK_SENSOR_STOP_CFM,	
	APP_GAS_LEAK_EVT_IND,
    APP_GAS_LEAK_SENSOR_RD_TIMER_ID, 	
	    
    APP_CUSTOM_COMMANDS_LAST,    
} ext_host_ble_aux_task_msg_t;

typedef enum {
    APP_STATUS_READY = 0x00,
    APP_STATUS_ADVERTISING = 0x01,
    APP_STATUS_CONNECTED = 0x02,
    APP_STATUS_CONNECTED_AND_ADVERTISING = 0x03,
} app_status_t;

typedef enum {
	APP_NO_ERROR = 0x00,
	APP_ERROR_INVALID_PARAMS,
    APP_ERROR_INVALID_SIZE,
} custom_command_status_t;

typedef enum {
    DEV_RESET_REASON_UNKNOWN = 0x00,
    DEV_RESET_REASON_WATCHDOG_TIMER,
    DEV_RESET_REASON_HARD_FAULT,   
    DEV_RESET_REASON_MEMORY_EXHAUSTED,
} dev_reset_reason_t;

typedef enum {
    APP_DEBUG_DUMP_TYPE_LLM_LE_ENV = 0x00,
    APP_DEBUG_DUMP_TYPE_LLC_ENV,
    APP_DEBUG_DUMP_TYPE_GATTM_ENV,
    APP_DEBUG_DUMP_TYPE_GATTC_ENV,
    APP_DEBUG_DUMP_TYPE_GAPM_ENV,
    APP_DEBUG_DUMP_TYPE_GAPC_ENV,
    //APP_DEBUG_DUMP_TYPE_ATTS_ENV,   //Not used
    APP_DEBUG_DUMP_TYPE_EM_BLE_CS,
    APP_DEBUG_DUMP_TYPE_EM_BLE_ET,
    APP_DEBUG_DUMP_TYPE_RECENT_GTL_COMMANDS,
} app_debug_dump_type_t;

typedef enum {
    APP_GTL_COM_ERROR_CODE_NO_ERROR = 0x00,
    APP_GTL_COM_ERROR_CODE_INVALID_INITIATOR,
    APP_GTL_COM_ERROR_CODE_INVALID_HEADER,
    APP_GTL_COM_ERROR_CODE_TIMEOUT,
} app_gtl_com_error_code_t;

/// Parameters of the @ref APP_GEN_RAND_REQ message
typedef struct app_gen_rand_req
{
    ///requested random number size
    uint8_t size;
} app_gen_rand_req_t;

/// Parameters of the @ref APP_GEN_RAND_RSP message
typedef struct app_gen_rand_rsp
{
    ///random number size
    uint8_t status;
    uint8_t size;
    uint8_t rand[__ARRAY_EMPTY];
} app_gen_rand_rsp_t;

/// Parameters of the @ref APP_STATUS_IND message
typedef struct app_status_ind
{
    ///Current status of the DA14531
    app_status_t status;
} app_status_ind_t;

/// Parameters of the @ref APP_SET_TX_POWER message
typedef struct app_set_tx_power
{
    ///TX power of the DA14531 to set
    uint8_t set_tx_power_variable;
} app_set_txpower_t;

/// Parameters of the @ref APP_SET_TX_POWER_CFM message
typedef struct app_set_tx_power_cfm
{
    ///TX power of the DA14531 to set
    custom_command_status_t status;
} app_set_tx_power_cfm_t;

/// Parameters of the @ref APP_SET_REG_VALUE message
typedef struct app_set_reg_value
{
    uint32_t address;
    uint32_t data;
    uint8_t size;
} app_set_reg_value_t;

/// Parameters of the @ref APP_SET_REG_VALUE_CFM message
typedef struct app_set_reg_value_cfm
{
    custom_command_status_t status;
} app_set_reg_value_cfm_t;

/// Parameters of the @ref APP_GET_REG_VALUE message
typedef struct app_get_reg_value
{
    uint32_t address;
    uint8_t size;
} app_get_reg_value_t;

/// Parameters of the @ref APP_GET_REG_VALUE_RSP message
typedef struct app_get_reg_value_rsp
{
    uint32_t address;
    uint32_t data;
    uint8_t size;
    custom_command_status_t status;
} app_get_reg_value_rsp_t;

/// Parameters of the @ref APP_STATS_IND message
typedef struct app_stats_ind
{
    uint32_t rx_packets;
    uint32_t rx_errors_all;
    uint32_t rx_errors_crc;
    uint32_t rx_errors_sync;
    uint16_t rssi;
} app_stats_ind_t;

/// Parameters of the @ref APP_DEV_RESET_IND message
typedef struct app_dev_reset_ind
{
    dev_reset_reason_t reason;
    uint32_t dump[RESET_DUMP_LENGTH_IN_BYTES/sizeof(uint32_t)];
} app_dev_reset_ind_t;

/// Parameters of the @ref APP_STATS_CONFIG_CMD
typedef struct app_stats_config_cmd
{  
    uint16_t interval;
    uint8_t enable;
    uint8_t reset_counters;
} app_stats_config_cmd_t;

/// Parameters of the @ref APP_CRC_ERROR_IND
typedef struct app_crc_error_ind
{  
    ke_msg_id_t msg_id;
    ke_task_id_t dest_id;
    ke_task_id_t src_id;
    uint16_t param_len;
    uint8_t received_crc;
    uint8_t calculated_crc;
} app_crc_error_ind_t;

/// Parameters of the @ref APP_MTU_CHANGED_IND
typedef struct app_mtu_changed_ind
{
    uint16_t mtu_size;   
} app_mtu_changed_ind_t;

/// Parameters of the @ref APP_STATS_CONFIG_CMD
typedef struct app_dbg_config_cmd
{  
    uint8_t operations;
    uint16_t stats_interval;
    uint8_t stats_enable;
    uint8_t stats_reset_counters;
    uint16_t i2c_message_max_len;
    uint16_t i2c_timeout;
    uint8_t gtl_com_err_ind_enable;   
} app_dbg_config_cmd_t;

typedef struct app_fw_version_ind
{
    uint8_t app_fw_version[APP_FW_VERSION_STRING_MAX_LENGTH];
}
app_fw_version_ind_t;




typedef struct app_get_debug_dump
{
    app_debug_dump_type_t app_debug_dump_type;
}
app_get_debug_dump_t;

typedef struct app_get_debug_dump_rsp
{
    app_debug_dump_type_t app_debug_dump_type;
    uint16_t size;
    uint8_t app_debug_dump[2];
}
app_get_debug_dump_rsp_t;

typedef struct app_gtl_com_err_ind
{
    app_gtl_com_error_code_t app_gtl_com_error_code;
    enum GTL_STATES_RX gtl_state_rx;
    uint16_t data_dump_bytes_count;
    uint8_t data_dump[2];
}
app_gtl_com_err_ind_t;



typedef struct app_svc_changed_cfg_cmd
{
    uint16_t ind_cfg;    
}
app_svc_changed_cfg_cmd_t;

typedef struct app_svc_changed_cfg_cfm
{ 
    custom_command_status_t status;
}
app_svc_changed_cfg_cfm_t;

extern const struct ke_state_handler ext_host_ble_aux_default_handler;
extern ke_state_t ext_host_ble_aux_state[EXT_HOST_BLE_AUX_IDX_MAX];

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief The function which prepares and sends the response to inform about the status
 * change of the BLE application (APP_STATUS_IND), e.g: Ready, Advertise, Connected...
 * @param[in] status  An enumerator describing the status.
 * @return void
 ****************************************************************************************
 */
void get_status(app_status_t status);


/**
 ****************************************************************************************
 * @brief The function which sends the message APP_DEV_RESET_IND to the external host,
 *        in order to provide information on the reason for the last abnormal reset
 * @return void
 ****************************************************************************************
 */
void app_dev_reset_ind_send(void);


/**
 ****************************************************************************************
 * @brief The function which sends the message APP_MTU_CHANGED_IND to the external host,
 *        when the MTU changes, in order to provide the new value of the MTU.
 * @param reason : The MTU value.
 * @return void
 ****************************************************************************************
 */
void app_mtu_changed_ind_send(uint16_t mtu);
void stats_ind_send(void);
void app_crc_error_ind_send(struct ke_msg *msg, uint8_t received_crc, uint8_t calculated_crc);
uint16_t get_custom_gtl_over_i2c_param_max_len(void);
void app_gtl_com_err_ind_send(app_gtl_com_error_code_t app_gtl_com_error_code, struct gtl_kemsghdr *gtl_com_err_cur_invalid_header, uint16_t invalid_data_bytes_count, uint8_t *invalid_data_dump);



void ext_host_ble_aux_task_init(void);


/**
 ****************************************************************************************
 * @brief The function which parses the log of the most recent headers of messages
          (up to a maximum of GTL_LOG_LAST_MESSAGES_COUNT messages) keeping only those
		  not included in the gtl_log_message_codes_to_filter_out array and returns a dump.          
 * @param[in] message_origin    Enumerator to indicate the origin of the message.
 * @param[in] buf               The actual messages.
 * @param[in] size              Size of the message.
 * @return  None.
 * @note    This function is called from ext_host_ble_aux_task.c, it is placed here since 
            there are some common functions with gtl_log_get_last_messages().
 ****************************************************************************************
 */
int8_t gtl_log_add_entry(message_metadata_origin_t message_origin, uint8_t *buf, uint8_t size);

#endif //EXT_HOST_BLE_AUX_TASK_H_



