/**
 ****************************************************************************************
 *
 * @file periph_setup.c
 *
 * @brief Peripherals setup and initialization.
 *
 * Copyright (C) 2012-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "user_periph_setup.h"
#include "datasheet.h"
#include "system_library.h"
#include "rwip_config.h"
#include "gpio.h"
#include "uart.h"
#include "syscntl.h"

#if (WLAN_COEX_ENABLED)
#include "wlan_coex.h"
#endif
#if defined (__PERI_GPIO_CONTROL__)
#include "ext_host_ble_aux_task.h"
#endif

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

#if (WLAN_COEX_ENABLED)
// Configuration struct for WLAN coexistence
const wlan_coex_cfg_t wlan_coex_cfg = {
    .ext_24g_eip_port = GPIO_PORT_0,
#if defined (__PERI_SAMPLE_QUAD_DEC__)
	.ext_24g_eip_pin  =  GPIO_PIN_11,
#else
    .ext_24g_eip_pin  =  GPIO_PIN_5,
#endif // __PERI_SAMPLE_QUAD_DEC__
    .ble_eip_port     = GPIO_PORT_0,
    .ble_eip_pin      =  GPIO_PIN_6,
#if defined (__BLE_EIP_PIN_2__)
	.ble_eip_pin_2      =  GPIO_PIN_2, // only p0_0 to p0_7 can be used
#endif // __BLE_EIP_PIN_2__
    .ble_prio_port    = GPIO_PORT_0,
    .ble_prio_pin     =  GPIO_PIN_7,
#if defined (CFG_WLAN_COEX_DEBUG)
    .debug_a_port = GPIO_PORT_0,
    .debug_a_pin  =  GPIO_PIN_9,
    .debug_b_port = GPIO_PORT_0,
    .debug_b_pin  =  GPIO_PIN_8,
#endif
    .irq = 4
};
#endif // WLAN_COEX_ENABLED

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
 */
#if defined (__ANT_CTRL_BY_BTACT__)
extern GPIO_PIN ble_eip_pin_1;
#if defined (__BLE_EIP_PIN_2__)
extern GPIO_PIN ble_eip_pin_2;
#endif // __BLE_EIP_PIN_2__
#endif // __ANT_CTRL_BY_BTACT__

#if DEVELOPMENT_DEBUG

void GPIO_reservations(void)
{
/*
    i.e. to reserve P0_1 as Generic Purpose I/O:
    RESERVE_GPIO(DESCRIPTIVE_NAME, GPIO_PORT_0, GPIO_PIN_1, PID_GPIO);
*/

    RESERVE_GPIO(UART1_TX, UART1_TX_PORT, UART1_TX_PIN, PID_UART1_TX);
    RESERVE_GPIO(UART1_RX, UART1_RX_PORT, UART1_RX_PIN, PID_UART1_RX);
    RESERVE_GPIO(UART1_RTS, UART1_RTSN_PORT, UART1_RTSN_PIN, PID_UART1_RTSN);
    RESERVE_GPIO(UART1_CTS, UART1_CTSN_PORT, UART1_CTSN_PIN, PID_UART1_CTSN);

#if defined (CFG_PRINTF_UART2)
    RESERVE_GPIO(UART2_TX,        UART2_TX_PORT,   UART2_TX_PIN,   PID_UART2_TX);
#endif

#if defined (CFG_WAKEUP_EXT_PROCESSOR)
    // external MCU wakeup GPIO
    RESERVE_GPIO(EXT_WAKEUP_GPIO, EXT_WAKEUP_PORT,      EXT_WAKEUP_PIN,      PID_GPIO);
#endif
    
#if (WLAN_COEX_ENABLED)	
	// wlan_coex_reservations();
#endif

#if (WLAN_COEX_ENABLED)
    RESERVE_GPIO(COEX_EIP, wlan_coex_cfg.ble_eip_port, wlan_coex_cfg.ble_eip_pin, PID_GPIO);
    RESERVE_GPIO(COEX_PRIO, wlan_coex_cfg.ble_prio_port, wlan_coex_cfg.ble_prio_pin, PID_GPIO);
    RESERVE_GPIO(COEX_REQ, wlan_coex_cfg.ext_24g_eip_port, wlan_coex_cfg.ext_24g_eip_pin, PID_GPIO);

#if defined (__BLE_EIP_PIN_2__)
    RESERVE_GPIO(COEX_EIP_2, wlan_coex_cfg.ble_eip_port, wlan_coex_cfg.ble_eip_pin_2, PID_GPIO);
#endif

#if defined (CFG_WLAN_COEX_DEBUG)
    RESERVE_GPIO(DEBUGPIN1, wlan_coex_cfg.debug_b_port, wlan_coex_cfg.debug_b_pin, PID_GPIO);
    RESERVE_GPIO(DEBUGPIN2, wlan_coex_cfg.debug_a_port, wlan_coex_cfg.debug_a_pin, PID_GPIO);
#endif
#endif

#if defined (__ANT_CTRL_BY_BTACT__)
	RESERVE_GPIO(BLE_EIP_1, GPIO_PORT_0, ble_eip_pin_1, PID_GPIO);
#if defined (__BLE_EIP_PIN_2__)
	RESERVE_GPIO(BLE_EIP_2, GPIO_PORT_0, ble_eip_pin_2, PID_GPIO);
#endif // __BLE_EIP_PIN_2__
#endif // __ANT_CTRL_BY_BTACT__

	// for peripheral driver samples
	RESERVE_GPIO(PERI_SAMPLE, GPIO_PORT_0, GPIO_PIN_2, PID_GPIO); // jtag
	RESERVE_GPIO(PERI_SAMPLE, GPIO_PORT_0, GPIO_PIN_8, PID_GPIO);
	RESERVE_GPIO(PERI_SAMPLE, GPIO_PORT_0, GPIO_PIN_10, PID_GPIO); // jtag
	RESERVE_GPIO(PERI_SAMPLE, GPIO_PORT_0, GPIO_PIN_11, PID_GPIO);			

}	
#endif

void usDelay2(uint32_t nof_us)
{
    while( nof_us-- ){
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
    }
}
#ifdef WIFI_WAKE_UP_VIA_UART_RTS //jason191130
void wkup_ext_processor(void)
{
    GPIO_ConfigurePin(UART1_CTSN_PORT, UART1_CTSN_PIN, OUTPUT, PID_GPIO, false);
    // Insert some delay if necessary current pulse duration is around 17us
		usDelay2(120);
    GPIO_ConfigurePin(UART1_CTSN_PORT, UART1_CTSN_PIN, OUTPUT, PID_UART1_CTSN, true);
}
#else
void wkup_ext_processor(void)
{
		//arch_printf("UART1_TX_PIN = %d \r\n",GPIO_GetPinStatus(UART1_TX_PORT, UART1_TX_PIN));
		//arch_printf("UART1_CTSN_PIN = %d \r\n",GPIO_GetPinStatus(UART1_CTSN_PORT, UART1_CTSN_PIN));
	
    // TX UART line should be high while idle
    //if (GPIO_GetPinStatus(UART1_TX_PORT, UART1_TX_PIN) && \
    //    GPIO_GetPinStatus(UART1_CTSN_PORT, UART1_CTSN_PIN))                         // Check that the other side is sleeping CTS should be high.
         GPIO_ConfigurePin(UART1_TX_PORT, UART1_TX_PIN, OUTPUT, PID_GPIO, false);    // configure TX pin as generic GPIO and force it low
					//GPIO_ConfigurePin(UART1_CTSN_PORT, UART1_CTSN_PIN, OUTPUT, PID_GPIO, true);    // configure TX pin as generic GPIO and force it low
    // Insert some delay if necessary current pulse duration is around 17us
		usDelay2(120);
    GPIO_ConfigurePin(UART1_TX_PORT, UART1_TX_PIN, OUTPUT, PID_UART1_TX, false);    // Switch back to uart functionallity
	    //GPIO_ConfigurePin(UART1_CTSN_PORT, UART1_CTSN_PIN, INPUT, PID_UART1_CTSN, false);
}
#endif

#if defined (__ANT_CTRL_BY_BTACT__)
void diagnostic_set_ble_eip_pin_inactive(void)
{
#if defined (CFG_WLAN_COEX_BLE_EVENT_INV)
    GPIO_ConfigurePin(GPIO_PORT_0, ble_eip_pin_1, OUTPUT, PID_GPIO, true);
#if defined (__BLE_EIP_PIN_2__)
	GPIO_ConfigurePin(GPIO_PORT_0, ble_eip_pin_2, OUTPUT, PID_GPIO, false);
#endif // __BLE_EIP_PIN_2__
#else
    GPIO_ConfigurePin(GPIO_PORT_0, ble_eip_pin_1, OUTPUT, PID_GPIO, false);
#if defined (__BLE_EIP_PIN_2__)
    GPIO_ConfigurePin(GPIO_PORT_0, ble_eip_pin_2, OUTPUT, PID_GPIO, true);
#endif // __BLE_EIP_PIN_2__
#endif // CFG_WLAN_COEX_BLE_EVENT_INV
}
#endif // __ANT_CTRL_BY_BTACT__

void set_pad_functions(void)
{
/*
    i.e. to set P0_1 as Generic purpose Output:
    GPIO_ConfigurePin(GPIO_PORT_0, GPIO_PIN_1, OUTPUT, PID_GPIO, false);
*/
#if defined (CFG_ENABLE_POR_PIN)
    GPIO_EnablePorPin(POR_PORT, POR_PIN, POR_POLARITY, 1);
#endif
#if defined (__DA14586__)
    // Disallow spontaneous DA14586 SPI Flash wake-up
    GPIO_ConfigurePin(GPIO_PORT_2, GPIO_PIN_3, OUTPUT, PID_GPIO, true);
#endif

#if defined (__DA14531_UART_DISABLE_AT_WIFI_SLEEP__)
	if (!is_wifi_in_sleep)
	{
#endif // __DA14531_UART_DISABLE_AT_WIFI_SLEEP__
	    GPIO_ConfigurePin(UART1_TX_PORT, UART1_TX_PIN, OUTPUT, PID_UART1_TX, false);
	    // GPIO_ConfigurePin(UART1_RX_PORT, UART1_RX_PIN, INPUT, PID_UART1_RX, false);
	    GPIO_ConfigurePin(UART1_RX_PORT, UART1_RX_PIN, INPUT_PULLUP, PID_UART1_RX, false);
	    GPIO_ConfigurePin(UART1_RTSN_PORT, UART1_RTSN_PIN, OUTPUT, PID_UART1_RTSN, false);
	    GPIO_ConfigurePin(UART1_CTSN_PORT, UART1_CTSN_PIN, INPUT, PID_UART1_CTSN, false);
#if defined (__DA14531_UART_DISABLE_AT_WIFI_SLEEP__)	
	}
#endif // __DA14531_UART_DISABLE_AT_WIFI_SLEEP__

#if defined (CFG_PRINTF_UART2)
    GPIO_ConfigurePin(UART2_TX_PORT, UART2_TX_PIN, OUTPUT, PID_UART2_TX, false);
#endif

#if defined (CFG_WAKEUP_EXT_PROCESSOR)
    // External MCU wakeup GPIO
    GPIO_ConfigurePin(EXT_WAKEUP_PORT, EXT_WAKEUP_PIN, OUTPUT, PID_GPIO, false);
#endif

#if defined (__DISABLE_JTAG_SWD_PINS_IN_BLE__)
	SetBits16(SYS_CTRL_REG, DEBUGGER_ENABLE, 0);
#endif // __DISABLE_JTAG_SWD_PINS_IN_BLE__

#if (WLAN_COEX_ENABLED)
	wlan_coex_gpio_cfg();
#endif // WLAN_COEX_ENABLED

#if defined (__ANT_CTRL_BY_BTACT__)
	diagnostic_set_ble_eip_pin_inactive();
#endif // __ANT_CTRL_BY_BTACT__

#if defined (__PERI_GPIO_CONTROL__)
    app_gtl_gpio_init();
#endif
}

#if defined (CFG_PRINTF_UART2)
// Configuration struct for UART2
static const uart_cfg_t uart_cfg = {
    .baud_rate = UART2_BAUDRATE,
    .data_bits = UART2_DATABITS,
    .parity = UART2_PARITY,
    .stop_bits = UART2_STOPBITS,
    .auto_flow_control = UART2_AFCE,
    .use_fifo = UART2_FIFO,
    .tx_fifo_tr_lvl = UART2_TX_FIFO_LEVEL,
    .rx_fifo_tr_lvl = UART2_RX_FIFO_LEVEL,
    .intr_priority = 2,
};
#endif

#if defined (__ANT_CTRL_BY_BTACT__)
GPIO_PIN ble_eip_pin_1 = GPIO_PIN_6;
#if defined (__BLE_EIP_PIN_2__)
GPIO_PIN ble_eip_pin_2 = GPIO_PIN_7;
#endif // __BLE_EIP_PIN_2__

void enable_diagnostic(void)
{
	uint8_t shift;

	if (ble_eip_pin_1 < GPIO_PIN_4)
	{
		shift = ble_eip_pin_1 * 8;
		// Enable BLE event in progress
		SetBits32(BLE_DIAGCNTL_REG, DIAG0 << shift, 0x1F);
		SetBits32(BLE_DIAGCNTL_REG, DIAG0_EN << shift, 1);
	}
	else
	{
		shift = (ble_eip_pin_1 - 4) * 8;
		// Enable BLE event in progress
		SetBits32(BLE_DIAGCNTL2_REG, DIAG4 << shift, 0x1F);
		SetBits32(BLE_DIAGCNTL2_REG, DIAG4_EN << shift, 1);
	}

#if defined (__BLE_EIP_PIN_2__)
	// configure the 2nd EIP pin on diagnostic pin 1
	if (ble_eip_pin_2 < GPIO_PIN_4)
	{
		shift = ble_eip_pin_2 * 8;
		// Enable BLE event in progress
		SetBits32(BLE_DIAGCNTL_REG, DIAG0 << shift, 0x1F);
		SetBits32(BLE_DIAGCNTL_REG, DIAG0_EN << shift, 1);
	}
	else
	{
		shift = (ble_eip_pin_2 - 4) * 8;
		// Enable BLE event in progress
		SetBits32(BLE_DIAGCNTL2_REG, DIAG4 << shift, 0x1F);
		SetBits32(BLE_DIAGCNTL2_REG, DIAG4_EN << shift, 1);
	}
#endif

#if defined (CFG_WLAN_COEX_BLE_EVENT_INV)
	SetBits32(BLE_DIAGCNTL3_REG, (DIAG0_INV << (ble_eip_pin_1 * 4)), 1);
#endif
	SetBits32(BLE_DIAGCNTL3_REG, (DIAG0_BIT << (ble_eip_pin_1 * 4)), 7);

#if defined (__BLE_EIP_PIN_2__)
#if !defined (CFG_WLAN_COEX_BLE_EVENT_INV)
	SetBits32(BLE_DIAGCNTL3_REG, (DIAG0_INV << (ble_eip_pin_2 * 4)), 1);
#endif
	SetBits32(BLE_DIAGCNTL3_REG, (DIAG0_BIT << (ble_eip_pin_2 * 4)), 7);
#endif

	// Configure selected GPIO as BLE diagnostic
	SetWord16(GPIO_BASE + 0x6 + (ble_eip_pin_1 << 1), 0x312);
#if defined (__BLE_EIP_PIN_2__)
	SetWord16(GPIO_BASE + 0x6 + (ble_eip_pin_2 << 1), 0x312);
#endif

}
#endif // __ANT_CTRL_BY_BTACT__

void periph_init(void)
{
#if defined (__DA14531__)
    // Disable HW RST on P0_0
    GPIO_Disable_HW_Reset();

    // In Boost mode enable the DCDC converter to supply VBAT_HIGH for the used GPIOs
    syscntl_dcdc_turn_on_in_boost(SYSCNTL_DCDC_LEVEL_3V0);
#else
    // Power up peripherals' power domain
    SetBits16(PMU_CTRL_REG, PERIPH_SLEEP, 0);
    while (!(GetWord16(SYS_STAT_REG) & PER_IS_UP));
    SetBits16(CLK_16M_REG, XTAL16_BIAS_SH_ENABLE, 1);
#endif

    // ROM patch
    patch_func();

#if defined (__DA14531_UART_DISABLE_AT_WIFI_SLEEP__)
	if (!is_wifi_in_sleep)  
#endif // __DA14531_UART_DISABLE_AT_WIFI_SLEEP__
	// Initialize UART1 ROM driver
	uart_init(BAUD_RATE_DIV(UART1_BAUDRATE), BAUD_RATE_FRAC(UART1_BAUDRATE), UART1_DATABITS);

#if defined (CFG_PRINTF_UART2)
    // Initialize UART2
    uart_initialize(UART2, &uart_cfg);
#endif

    // Set pad functionality
    set_pad_functions();

    // Enable the pads
    GPIO_set_pad_latch_en(true);
}


#if defined (__DA14531_UART_DISABLE_AT_WIFI_SLEEP__)

void gtl_uart_enable(void)
{
	periph_init();
}

void gtl_uart_disable(void)
{

	GPIO_ConfigurePin(UART1_TX_PORT, UART1_TX_PIN, INPUT, PID_GPIO, false);
	GPIO_ConfigurePin(UART1_RX_PORT, UART1_RX_PIN, INPUT, PID_GPIO, false);
	GPIO_ConfigurePin(UART1_RTSN_PORT, UART1_RTSN_PIN, INPUT, PID_GPIO, false);
	
	GPIO_ConfigurePin(UART1_CTSN_PORT, UART1_CTSN_PIN, INPUT, PID_GPIO, false);
	// GPIO_ConfigurePin(UART1_CTSN_PORT, UART1_CTSN_PIN, INPUT, PID_GPIO, true); // wk
	// GPIO_ConfigurePin(UART1_CTSN_PORT, UART1_CTSN_PIN, OUTPUT, PID_GPIO, false); // wk

}
#endif // __DA14531_UART_DISABLE_AT_WIFI_SLEEP__

