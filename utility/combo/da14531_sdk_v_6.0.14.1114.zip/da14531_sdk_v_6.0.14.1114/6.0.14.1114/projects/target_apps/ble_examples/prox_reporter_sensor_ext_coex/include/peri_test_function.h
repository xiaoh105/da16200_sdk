/**
 ****************************************************************************************
 *
 * @file peri_test_function.h
 *
 * @brief test functions for peripheral drivers
 *
 * Copyright (C) 2012-2020 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef PERI_TEST_FUNCTION_H_
#define PERI_TEST_FUNCTION_H_

#include "user_periph_setup.h"

/**
 ****************************************************************************************
 * @brief SPI Flash test function
 ****************************************************************************************
 */
void app_peri_spi_flash_run(void);

/**
 ****************************************************************************************
 * @brief SPI and SPI Flash Initialization function
 ****************************************************************************************
 */
static void spi_flash_peripheral_init(void);
/**
 ****************************************************************************************
 * @brief SPI Flash protection features test
 ****************************************************************************************
 */
static void spi_protection_features_test(void);

/**
 ****************************************************************************************
 * @brief SPI Flash power mode for Macronix test
 ****************************************************************************************
 */
static void print_MX25R_power_mode(void);

/**
 ****************************************************************************************
 * @brief SPI Flash Read/Write test
 ****************************************************************************************
 */
static void spi_read_write_test(void);

/**
 ****************************************************************************************
 * @brief SPI Flash Read/Write test
 ****************************************************************************************
 */
static void spi_read_write_test_buffer(void);

#if defined (CFG_SPI_DMA_SUPPORT)
static void spi_read_write_test_dma(void);
#endif

void app_peri_blinky_run(void);
void app_peri_blinky_run_start(void);

void app_peri_systick_run(void);
void app_peri_timer0_gen_run(void);
void app_peri_timer0_gen_stop(void);
void app_peri_timer0_buz_run(void);
void app_peri_timer0_buz_stop(void);
void app_peri_timer2_pwm_run(void);
void app_peri_spi_flash_run(void);
void app_peri_i2c_eeprom_run(void);
void app_peri_quad_dec_run(void);
void app_peri_quad_dec_stop(void);

#endif // PERI_TEST_FUNCTION_H_
