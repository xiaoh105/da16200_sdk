/**
 ****************************************************************************************
 *
 * @file user_uart_gtl.h
 *
 * @brief ROM overridden functions for propriety GTL protocol header file.
 *
 * Copyright (C) 2015-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef _USER_UART_GTL_H_
#define _USER_UART_GTL_H_

/**
 ****************************************************************************************
 * @addtogroup APP
 * @ingroup RICOW
 *
 * @brief 
 *
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "rwble_config.h"
#include "gapc_task.h"                 // gap functions and messages
#include "gapm_task.h"                 // gap functions and messages
#include "co_error.h"                  // error code definitions

/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Pathed uart flow on function executed by the ROM code.
 ****************************************************************************************
*/

void uart_flow_on_func_custom(void);

/**
 ****************************************************************************************
 * @brief Patched uart flow off function executed by the ROM code.
 ****************************************************************************************
*/

bool uart_flow_off_func_custom(void);

/**
 ****************************************************************************************
 * @brief Patched uart write function executed by the ROM code.
 ****************************************************************************************
*/

void uart_write_func_custom(uint8_t *bufptr, uint32_t size,void (*callback) (uint8_t));

/**
 ****************************************************************************************
 * @brief Patched gtl eif init function executed by the ROM code.
 ****************************************************************************************
*/

void gtl_eif_init_func_custom(void);

/**
 ****************************************************************************************
 * @brief Poll external wake up request while device is awake to issue a flow on.
 ****************************************************************************************
*/
arch_main_loop_callback_ret_t poll_external_wake_up_req(void);

/**
 ****************************************************************************************
 * @brief Enable wakeup controller for monitoring external interrupt trigger.
 ****************************************************************************************
*/
void ext_wakeup_enable_custom(uint32_t port, uint32_t pin, uint8_t polarity);

/**
 ****************************************************************************************
 * @brief Disable wakeup controller.
 ****************************************************************************************
*/
void ext_wakeup_disable_custom(void);

/// @} APP

#endif // _USER_UART_GTL_H_
