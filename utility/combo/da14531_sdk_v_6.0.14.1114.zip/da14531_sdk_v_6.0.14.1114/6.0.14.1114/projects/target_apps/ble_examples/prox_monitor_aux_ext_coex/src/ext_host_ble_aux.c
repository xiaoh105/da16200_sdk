/**
 ****************************************************************************************
 *
 * @file ext_host_ble_aux.c
 *
 * @brief 
 *
 * Copyright (C) 2016. Dialog Semiconductor Ltd, unpublished work. This computer
 * program includes Confidential, Proprietary Information and is a Trade Secret of
 * Dialog Semiconductor Ltd.  All use, disclosure, and/or reproduction is prohibited
 * unless authorized in writing. All Rights Reserved.
 *
 * <bluetooth.support@diasemi.com> and contributors.
 *
 ****************************************************************************************
 */
 
#include "ext_host_ble_aux.h"
#include "ext_host_ble_aux_task.h"
#include "ke_task.h"
 
 
 
/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */



// Ext Host BLE Auxiliary task descriptor
static const struct ke_task_desc TASK_DESC_EXT_HOST_BLE_AUX = {NULL, &ext_host_ble_aux_default_handler, ext_host_ble_aux_state, EXT_HOST_BLE_AUX_STATE_MAX, EXT_HOST_BLE_AUX_IDX_MAX};

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
 */

void ext_host_ble_aux_init(void)
{
    // Create EXT_HOST_BLE_AUX task
    ke_task_create(TASK_EXT_HOST_BLE_AUX, &TASK_DESC_EXT_HOST_BLE_AUX);

    // Set task in disabled state
    ke_state_set(TASK_EXT_HOST_BLE_AUX, EXT_HOST_BLE_AUX_DISABLED);
} 

