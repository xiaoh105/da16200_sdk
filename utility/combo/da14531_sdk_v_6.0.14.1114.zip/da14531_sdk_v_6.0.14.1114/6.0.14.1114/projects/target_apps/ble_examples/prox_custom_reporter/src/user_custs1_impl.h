/**
 ****************************************************************************************
 *
 * @file user_custs1_impl.h
 *
 * @brief Peripheral project Custom1 Server implementation header file.
 *
 * Copyright (C) 2015-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef _USER_CUSTS1_IMPL_H_
#define _USER_CUSTS1_IMPL_H_

/**
 ****************************************************************************************
 * @addtogroup APP
 * @ingroup RICOW
 *
 * @brief
 *
 * @{
 ****************************************************************************************
 */
#include "user_custs1_def.h"

/*
 * DEFINES
 ****************************************************************************************
 */
#define USER_CUSTS1_REPORT_MAX_SIZE                  (DEMO_PEER_MAX_MTU)


/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "gapc_task.h"                 // gap functions and messages
#include "gapm_task.h"                 // gap functions and messages
#include "custs1_task.h"

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
void user_custs1_init(void);
void user_custs1_handler(ke_msg_id_t const msg_id, void *msg);
void user_custs1_report_create_and_send(uint8_t handle, uint8_t *data, uint8_t len);
void user_custs1_report_to_host(uint8_t handle, uint8_t *data, uint8_t len);
void user_app_adc_report(uint8_t sample);
void user_custs1_value_set_req(uint8_t handle, uint8_t *data, uint16_t length);

/// @} APP

#endif // _USER_CUSTS1_IMPL_H_
