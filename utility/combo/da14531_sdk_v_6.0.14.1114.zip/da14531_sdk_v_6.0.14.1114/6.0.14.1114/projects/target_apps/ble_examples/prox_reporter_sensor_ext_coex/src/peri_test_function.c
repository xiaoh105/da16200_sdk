/**
 ****************************************************************************************
 *
 * @file peri_test_function.c
 *
 * @brief peripheral driver test functions
 *
 * Copyright (C) 2012-2020 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <stdio.h>
#include <stdint.h>
#include "arch_system.h"
#include "gpio.h"
#include "uart.h"
#include "uart_utils.h"
#include "ke_mem.h"

#include "systick.h"

#include "spi.h"
#include "spi_flash.h"

#include "i2c.h"
#include "i2c_eeprom.h"

#include "wkupct_quadec.h"

#include "peri_test_function.h"
#include "arch_api.h"
#if defined (CFG_PRINTF)
#include "arch_console.h"
#endif
extern void usDelay2(uint32_t nof_us);

#if defined (__PERI_SAMPLE_TIMER0_GEN__)
#define NO_PWM            0x0                       // PWM not used
app_peri_timer0_gen_start_t config_test_data;
#endif

#if defined (__PERI_SAMPLE_TIMER0_BUZ__) || defined (__PERI_SAMPLE_TIMER0_GEN__) || defined (__PERI_SAMPLE_TIMER2_PWM__)
tim0_2_clk_div_config_t clk_div_config;
#endif

#if defined (__PERI_SAMPLE_BLINKY__)
GPIO_PIN blinky_gpio_pin  __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
GPIO_PORT blinky_gpio_port  __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t blinky_blink_cnt  __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t blinky_blink_on __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY

void app_peri_blinky_run_start()
{
    printf_string(UART2, "\n\r\n\r");
    printf_string(UART2, "***************\n\r");
    printf_string(UART2, "* BLINKY DEMO *\n\r");
    printf_string(UART2, "***************\n\r");

	blinky_blink_on = 1;
    app_peri_blinky_run();
}

void app_peri_blinky_run()
{
	GPIO_ConfigurePin(blinky_gpio_port, blinky_gpio_pin, OUTPUT, PID_GPIO, false);

	if (blinky_blink_on)
	{
		GPIO_SetActive(blinky_gpio_port, blinky_gpio_pin);
		printf_string(UART2, "\n\r *LED ON* ");
		blinky_blink_on = 0;
	} else {

		GPIO_SetInactive(blinky_gpio_port, blinky_gpio_pin);
#if defined (CFG_PRINTF)
		arch_printf("\n\r *LED OFF* (%d) ", blinky_blink_cnt);
#endif
		blinky_blink_cnt--;
		if (blinky_blink_cnt)
		{
			blinky_blink_on = 1;
		}
		else
		{
			blinky_blink_on = 0;
			printf_string(UART2, "\n\r");
			return;
		}
	}
	ke_timer_set(APP_PERI_BLINKY_RUN_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_PERI_SAMPLE_LED_RUN);
}
#endif // __PERI_SAMPLE_BLINKY__

#if defined (__PERI_SAMPLE_SYSTICK__)
#define SYSTICK_EXCEPTION   1           // generate systick exceptions
GPIO_PORT systick_gpio_port;
GPIO_PIN systick_gpio_pin;
uint32_t systick_period_us;
uint32_t systick_period_tu;
static int i = 0;

static void app_peri_systick_isr(void)
{
    if (i == 0)
    {
        GPIO_SetActive(systick_gpio_port, systick_gpio_pin);
        i = 1;
    }
    else
    {
        GPIO_SetInactive(systick_gpio_port, systick_gpio_pin);
        i = 0;
    }
}

void app_peri_systick_run()
{
	GPIO_ConfigurePin(systick_gpio_port, systick_gpio_pin, OUTPUT, PID_GPIO, false);

	systick_register_callback(app_peri_systick_isr);
		
	// Systick will be initialized to use a reference clock frequency of 1 MHz
	systick_start(systick_period_us, SYSTICK_EXCEPTION);
}

#endif // __PERI_SAMPLE_SYSTICK__

static void app_timer0_stop(void)
{
    timer0_stop();
    // Disable the Timer0/Timer2 input clock
    timer0_2_clk_disable();

    printf_string(UART2, "\n\rTIMER0 stopped!\n\r");
    printf_string(UART2, "\n\rEnd of test\n\r");
}

#if defined (__PERI_SAMPLE_TIMER0_GEN__)
void app_peri_timer0_gen_stop(void)
{
	app_timer0_stop();
	config_test_data.test_dur = 0;
	GPIO_SetInactive((GPIO_PORT)config_test_data.gpio_port, 
					(GPIO_PIN)config_test_data.gpio_pin);
	arch_set_extended_sleep(false);
}

/**
 ****************************************************************************************
 * @brief Timer0 general user callback function
 *
 ****************************************************************************************
 */
static void timer0_general_user_callback_function(void)
{
    static uint8_t n = 0;

    // when pass  10 * 100ms
    if ( 10 == n )
    {
        n = 0;
        if (GPIO_GetPinStatus((GPIO_PORT)config_test_data.gpio_port, (GPIO_PIN)config_test_data.gpio_pin))
        {
            GPIO_SetInactive((GPIO_PORT)config_test_data.gpio_port, (GPIO_PIN)config_test_data.gpio_pin);
        }
        else
        {
            GPIO_SetActive((GPIO_PORT)config_test_data.gpio_port, (GPIO_PIN)config_test_data.gpio_pin);
        }
     }
     n++;
}

void app_peri_timer0_gen_run(void)
{
    timer0_2_clk_disable();

    GPIO_ConfigurePin((GPIO_PORT)config_test_data.gpio_port, 
                      (GPIO_PIN)config_test_data.gpio_pin, OUTPUT, PID_GPIO, false);

    GPIO_SetActive((GPIO_PORT)config_test_data.gpio_port, 
                   (GPIO_PIN)config_test_data.gpio_pin);

    printf_string(UART2, "\n\r\n\r");
    printf_string(UART2, "***********************\n\r");
    printf_string(UART2, "* TIMER0 GENERAL TEST *\n\r");
    printf_string(UART2, "***********************\n\r");

    // Stop timer for enter settings
    timer0_stop();

    // register callback function for SWTIM_IRQn irq
    timer0_register_callback(timer0_general_user_callback_function);

    // Enable the Timer0/Timer2 input clock
    timer0_2_clk_enable();

    // Set the Timer0/Timer2 input clock division factor to 8, so 16 MHz / 8 = 2 MHz input clock
    timer0_2_clk_div_set(&clk_div_config);

    // clear PWM settings register to not generate PWM
    timer0_set_pwm_high_counter(NO_PWM);
    timer0_set_pwm_low_counter(NO_PWM);

    // e.g.) Set timer with 2MHz source clock divided by 10 so Fclk = 2MHz/10 = 200kHz
    timer0_init(config_test_data.timer0_clk_src, config_test_data.pwm_mode, config_test_data.timer0_clk_div);

    // reload value for 100ms (T = 1/200kHz * RELOAD_100MS = 0,000005 * 20000 = 100ms)
    timer0_set_pwm_on_counter(config_test_data.reload_val);

    // Enable SWTIM_IRQn irq
    timer0_enable_irq();

    printf_string(UART2, "\n\rLED will change state by the timer0.\n\r");
    printf_string(UART2, "\n\rTest will run for: ");
    printf_byte_dec(UART2, config_test_data.test_dur);
    printf_string(UART2, " seconds.\n\r");

    // Start Timer0
    timer0_start();
    printf_string(UART2, "\n\rTIMER0 started!\r\n");

    ke_timer_set(APP_PERI_TIMER0_GEN_STOP_TIMER_ID, TASK_EXT_HOST_BLE_AUX, config_test_data.test_dur*100);
}
#endif // __PERI_SAMPLE_TIMER0_GEN__

#if defined (__PERI_SAMPLE_TIMER0_BUZ__)
#define ALL_NOTES       26
app_peri_timer0_buz_start_t conf_buz;
#define BUZ_ON_CNT		0xFFFF
#define BUZ_CNT_LOOP	10
// table with values used for setting different PWM duty cycle to change the "melody" played by buzzer
const uint16_t notes[ALL_NOTES] = {1046, 987, 767, 932, 328, 880, 830, \
                                   609, 783, 991, 739, 989, 698, 456,  \
                                   659, 255, 622, 254, 587, 554, 365,  \
                                   523, 251, 493, 466, 440};

/**
 ****************************************************************************************
 * @brief User callback function called by SWTIM_IRQn interrupt. Function is changing
 *        "note" played by buzzer by changing PWM duty cycle.
 ****************************************************************************************
 */ 
static void pwm0_user_callback_function(void)
{ 
    static uint8_t n = 0;
    static uint8_t i = 0;

    if (n == BUZ_CNT_LOOP) //change "note" every 10 * 32,768ms
    {
        n = 0;
        // Change note and set ON-counter to Ton = 1/2Mhz * 65536 = 32,768ms
        timer0_set_pwm_on_counter(BUZ_ON_CNT);
        timer0_set_pwm_high_counter(notes[i]/3 * 2);
        timer0_set_pwm_low_counter(notes[i]/3);

        printf_string(UART2, "*");
        
        // limit i iterator to max index of table of notes
        i = (i+1) % (ALL_NOTES - 1);
    }
    n++;
}

void app_peri_timer0_buz_stop(void)
{
	app_timer0_stop();
	conf_buz.buz_tst_counter = 0;
	GPIO_ConfigurePin((GPIO_PORT)conf_buz.t0_pwm0_port, 
			(GPIO_PIN)conf_buz.t0_pwm0_pin, OUTPUT, PID_GPIO, false);
	GPIO_ConfigurePin((GPIO_PORT)conf_buz.t0_pwm1_port, 
			(GPIO_PIN)conf_buz.t0_pwm1_pin, OUTPUT, PID_GPIO, false);

	arch_set_extended_sleep(false);
}

void app_peri_timer0_buz_run(void)
{
	uint32_t period = 0;

    timer0_2_clk_disable();

    // Configure PWM pin functionality
    GPIO_ConfigurePin((GPIO_PORT)conf_buz.t0_pwm0_port, (GPIO_PIN)conf_buz.t0_pwm0_pin, OUTPUT, PID_PWM0, true);
    GPIO_ConfigurePin((GPIO_PORT)conf_buz.t0_pwm1_port, (GPIO_PIN)conf_buz.t0_pwm1_pin, OUTPUT, PID_PWM1, true);

    printf_string(UART2, "\n\r\n\r");
    printf_string(UART2, "*******************\n\r");
    printf_string(UART2, "* TIMER0 PWM TEST *\n\r");
    printf_string(UART2, "*******************\n\r");

	// Enable the Timer0/Timer2 input clock
	timer0_2_clk_enable();

	// Set the Timer0/Timer2 input clock division factor to 8, so 16 MHz / 8 = 2 MHz input clock
	timer0_2_clk_div_set(&clk_div_config);
	

	// initialize PWM with the desired settings
	timer0_init(conf_buz.t0_clk_src, conf_buz.t0_pwm_mod, conf_buz.t0_clk_div);

	// set pwm Timer0 'On', Timer0 'high' and Timer0 'low' reload values
	timer0_set(conf_buz.t0_on_reld_val, conf_buz.t0_high_reld_val, conf_buz.t0_low_reld_val);

	// register callback function for SWTIM_IRQn irq
	timer0_register_callback(pwm0_user_callback_function);

	// enable SWTIM_IRQn irq
	timer0_enable_irq();

	printf_string(UART2, "\n\rTIMER0 starts!");
	printf_string(UART2, "\n\rYou can hear the sound produced by PWM0 or PWM1");
	printf_string(UART2, "\n\rif you attach a buzzer on pins P0_8 or P0_11 respectively.");
	printf_string(UART2, "\n\rPlaying melody. Please wait...\n\r");

	// start pwm0
	timer0_start();

	period = (BUZ_ON_CNT + 1)/(16/(1 << clk_div_config.clk_div))*BUZ_CNT_LOOP*conf_buz.buz_tst_counter/10000+1;
	ke_timer_set(APP_PERI_TIMER0_BUZ_STOP_TIMER_ID, TASK_EXT_HOST_BLE_AUX, period);
}
#endif // __PERI_SAMPLE_TIMER0_BUZ__

#if defined (__PERI_SAMPLE_TIMER2_PWM__)
app_peri_timer2_pwm_start_t conf_pwm;
tim2_config_t config_t2_pwm;
tim2_pwm_config_t pwm_config;

void app_peri_timer2_pwm_run(void)
{
    uint8_t i;

	// Configure PWM pin functionality
    GPIO_ConfigurePin((GPIO_PORT)conf_pwm.t2_pwm_port, (GPIO_PIN)conf_pwm.t2_pwm_pin[0].gpio_pin, OUTPUT, PID_PWM2, true);
    GPIO_ConfigurePin((GPIO_PORT)conf_pwm.t2_pwm_port, (GPIO_PIN)conf_pwm.t2_pwm_pin[1].gpio_pin, OUTPUT, PID_PWM3, true);

	if (conf_pwm.t2_pwm_pin[2].is_used == true)
 	   GPIO_ConfigurePin((GPIO_PORT)conf_pwm.t2_pwm_port, (GPIO_PIN)conf_pwm.t2_pwm_pin[2].gpio_pin, OUTPUT, PID_PWM4, true);

    printf_string(UART2, "\n\r\n\r***************");
    printf_string(UART2, "\n\r* TIMER2 TEST *\n\r");
    printf_string(UART2, "***************\n\r");

    // Enable the Timer0/Timer2 input clock
    timer0_2_clk_enable();
    // Set the Timer0/Timer2 input clock division factor
    timer0_2_clk_div_set(&clk_div_config);

    timer2_config(&config_t2_pwm);

    // System clock, divided by 8, is the Timer2 input clock source (according
    // to the clk_div_config struct above).
    timer2_pwm_freq_set(conf_pwm.t2_pwm_freq, (16000000) / ((1) << (conf_pwm.t0_t2_in_clk_div_factor)));

    timer2_start();

    printf_string(UART2, "\n\rTIMER2 started!");
    for (i = 0; i < 100; i += 10)
    {
		//arch_printf("i=%d\n", i);
		
        // Set PWM2 duty cycle
        if (conf_pwm.t2_pwm_pin[0].is_used == true)
        {
	        pwm_config.pwm_signal = TIM2_PWM_2;
	        pwm_config.pwm_dc     = i;
			pwm_config.pwm_offset = 0;
	        timer2_pwm_signal_config(&pwm_config);
        }
        
        // Set PWM3 duty cycle
        if (conf_pwm.t2_pwm_pin[1].is_used == true)
        {
	        pwm_config.pwm_signal = TIM2_PWM_3;
	        pwm_config.pwm_dc     = i + 5;
			pwm_config.pwm_offset = 0;
	        timer2_pwm_signal_config(&pwm_config);
        }
        
        // Set PWM4 duty cycle
        if (conf_pwm.t2_pwm_pin[2].is_used == true)
        {
	        pwm_config.pwm_signal = TIM2_PWM_4;
	        pwm_config.pwm_dc     = i + 10;
			pwm_config.pwm_offset = 0;
	        timer2_pwm_signal_config(&pwm_config);
        }
        
        // Release sw pause to let PWM2, PWM3, and PWM4 run
        timer2_resume();

        // Delay approx. 1 second to observe duty cycle change
        usDelay2(1000000);

        timer2_pause();
    }

    timer2_stop();

    // Disable the Timer0/Timer2 input clock
    timer0_2_clk_disable();

    printf_string(UART2, "\n\rTIMER2 stopped!\n\r");
    printf_string(UART2, "\n\rEnd of test\n\r");

    GPIO_ConfigurePin((GPIO_PORT)conf_pwm.t2_pwm_port, 
					  (GPIO_PIN)conf_pwm.t2_pwm_pin[0].gpio_pin, OUTPUT, PID_GPIO, false);
	
    GPIO_ConfigurePin((GPIO_PORT)conf_pwm.t2_pwm_port, 
					  (GPIO_PIN)conf_pwm.t2_pwm_pin[1].gpio_pin, OUTPUT, PID_GPIO, false);
	
	if (conf_pwm.t2_pwm_pin[2].is_used == true)
	{
 	   GPIO_ConfigurePin((GPIO_PORT)conf_pwm.t2_pwm_port, 
	   				(GPIO_PIN)conf_pwm.t2_pwm_pin[2].gpio_pin, OUTPUT, PID_GPIO, false);
	}
}
#endif // __PERI_SAMPLE_TIMER2_PWM__

#if defined (__PERI_SAMPLE_SPI_FLASH__)
// Define SPI Configuration

#define SPI_EN_PORT 			GPIO_PORT_0
#define SPI_EN_PIN				GPIO_PIN_8

#define SPI_CLK_PORT			GPIO_PORT_0
#define SPI_CLK_PIN 			GPIO_PIN_11

#define SPI_DO_PORT 			GPIO_PORT_0
#define SPI_DO_PIN				GPIO_PIN_2

#define SPI_DI_PORT 			GPIO_PORT_0
#define SPI_DI_PIN				GPIO_PIN_10


#define SPI_MS_MODE             SPI_MS_MODE_MASTER
#define SPI_CP_MODE             SPI_CP_MODE_0
#define SPI_WSZ                 SPI_MODE_8BIT
#define SPI_CS                  SPI_CS_0

#if defined(__DA14531__)
#define SPI_SPEED_MODE          SPI_SPEED_MODE_4MHz
#define SPI_EDGE_CAPTURE        SPI_MASTER_EDGE_CAPTURE
#else // (DA14585, DA14586)
    #define SPI_SPEED_MODE          SPI_SPEED_MODE_4MHz
#endif

/****************************************************************************************/
/* SPI Flash configuration                                                              */
/****************************************************************************************/
#if !defined (__DA14586__)
#define SPI_FLASH_DEV_SIZE          (256 * 1024)
#endif

// Configuration struct for SPI
static const spi_cfg_t spi_cfg = {
    .spi_ms = SPI_MS_MODE,
    .spi_cp = SPI_CP_MODE,
    .spi_speed = SPI_SPEED_MODE,
    .spi_wsz = SPI_WSZ,
    .spi_cs = SPI_CS,
    .cs_pad.port = SPI_EN_PORT,
    .cs_pad.pin = SPI_EN_PIN,
#if defined (__DA14531__)
    .spi_capture = SPI_EDGE_CAPTURE,
#endif
#if defined (CFG_SPI_DMA_SUPPORT)
    .spi_dma_channel = SPI_DMA_CHANNEL_01,
    .spi_dma_priority = DMA_PRIO_0,
#endif
};

// Configuration struct for SPI FLASH
static const spi_flash_cfg_t spi_flash_cfg = {
    .chip_size = SPI_FLASH_DEV_SIZE,
};

//uint8_t rd_data_spi[512];
uint8_t* rd_data_spi;

//uint8_t wr_data_spi[512];
uint8_t* wr_data_spi;


uint8_t dev_id;

/**
 ****************************************************************************************
 * @brief SPI and SPI Flash Initialization function
 ****************************************************************************************
 */
static void spi_flash_peripheral_init(void)
{
    // Release Flash from power down
    spi_flash_release_from_power_down();

    // Try to auto-detect the device
    spi_flash_auto_detect(&dev_id);
}

/**
 ****************************************************************************************
 * @brief SPI Flash protection features test
 ****************************************************************************************
 */
static void spi_protection_features_test(void)
{
    unsigned char buf1[][2] = {{0xE0, 0x0E}, {0xD0, 0x0D}, {0xB0, 0x0B}, {0x70, 0x07}};
    uint32_t actual_size;
    printf_string(UART2, "\n\r\n\r");
    switch(dev_id)
    {
        case W25X10CL_DEV_INDEX:
        {
            printf_string(UART2, "\n\rW25X10CL SPI memory protection features demo.\n\r");

            // 1. Unprotected memory
            printf_string(UART2, "\n\r1) Unprotected memory test\n\r");
            printf_string(UART2, "\tPerforming a full erase...\n\r");
            spi_flash_chip_erase_forced();  // the whole memory array gets unprotected in this function

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x10000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xFF \t [0x10000] = 0xFF\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xE0 \t [0x10000] = 0x0E\n\r");
            spi_flash_write_data(&buf1[0][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[0][1], 0x10000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x10000] = 0x0E\n\r");

            // 2. Full protected memory
            printf_string(UART2, "\n\r2) Full protected memory test\n\r");
            spi_flash_configure_memory_protection(W25X10CL_MEM_PROT_ALL);
            printf_string(UART2, "\tPerforming a full erase...\n\r");
            spi_flash_chip_erase();

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x10000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x10000] = 0x0E\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xD0 \t [0x10000] = 0x0D\n\r");
            spi_flash_write_data(&buf1[1][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[1][1], 0x10000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x10000] = 0x0E\n\r");

            // 3. Lower half protected memory
            printf_string(UART2, "\n\r3) Lower half protected memory test\n\r");
            spi_flash_configure_memory_protection(W25X10CL_MEM_PROT_LOWER_HALF);
            printf_string(UART2, "\tPerforming a Sector Erase at addresses 0x00000 and 0x10000...\n\r");
            spi_flash_block_erase(0, SPI_FLASH_OP_SE);
            spi_flash_block_erase(0x10000, SPI_FLASH_OP_SE);

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x10000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x10000] = 0xFF\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xB0 \t [0x10000] = 0x0B\n\r");
            spi_flash_write_data(&buf1[2][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[2][1], 0x10000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x10000] = 0x0B\n\r");

            // 4. Upper half protected memory
            printf_string(UART2, "\n\r4) Upper half protected memory test\n\r");
            spi_flash_configure_memory_protection(W25X10CL_MEM_PROT_UPPER_HALF);
            printf_string(UART2, "\tPerforming a Sector Erase at addresses 0x00000 and 0x10000...\n\r");
            spi_flash_block_erase(0, SPI_FLASH_OP_SE);
            spi_flash_block_erase(0x10000, SPI_FLASH_OP_SE);

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x10000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xFF \t [0x10000] = 0x0B\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0x70 \t [0x10000] = 0x07\n\r");
            spi_flash_write_data(&buf1[3][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[3][1], 0x10000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0x70 \t [0x10000] = 0x0B\n\r");

            break;
        }

        case W25X20CL_DEV_INDEX:
        {
            printf_string(UART2, "\n\rW25X20CL SPI memory protection features demo.\n\r");

            // 1. Unprotected memory
            printf_string(UART2, "\n\r1) Unprotected memory test\n\r");
            printf_string(UART2, "\tPerforming a full erase...\n\r");
            spi_flash_chip_erase_forced();  // the whole memory array gets unprotected in this function

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x20000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xFF \t [0x20000] = 0xFF\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xE0 \t [0x20000] = 0x0E\n\r");
            spi_flash_write_data(&buf1[0][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[0][1], 0x20000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x20000] = 0x0E\n\r");

            // 2. Full protected memory
            printf_string(UART2, "\n\r2) Full protected memory test\n\r");
            spi_flash_configure_memory_protection(W25X20CL_MEM_PROT_ALL);
            printf_string(UART2, "\tPerforming a full erase...\n\r");
            spi_flash_chip_erase();

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x20000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x20000] = 0x0E\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xD0 \t [0x20000] = 0x0D\n\r");
            spi_flash_write_data(&buf1[1][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[1][1], 0x20000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x20000] = 0x0E\n\r");

            // 3. Lower half protected memory
            printf_string(UART2, "\n\r3) Lower half protected memory test\n\r");
            spi_flash_configure_memory_protection(W25X20CL_MEM_PROT_LOWER_HALF);
            printf_string(UART2, "\tPerforming a Sector Erase at addresses 0x00000 and 0x20000...\n\r");
            spi_flash_block_erase(0, SPI_FLASH_OP_SE);
            spi_flash_block_erase(0x20000, SPI_FLASH_OP_SE);

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x20000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x20000] = 0xFF\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xB0 \t [0x20000] = 0x0B\n\r");
            spi_flash_write_data(&buf1[2][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[2][1], 0x20000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x20000] = 0x0B\n\r");

            // 4. Upper half protected memory
            printf_string(UART2, "\n\r4) Upper half protected memory test\n\r");
            spi_flash_configure_memory_protection(W25X20CL_MEM_PROT_UPPER_HALF);
            printf_string(UART2, "\tPerforming a Sector Erase at addresses 0x00000 and 0x20000...\n\r");
            spi_flash_block_erase(0, SPI_FLASH_OP_SE);
            spi_flash_block_erase(0x20000, SPI_FLASH_OP_SE);

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x20000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xFF \t [0x20000] = 0x0B\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0x70 \t [0x20000] = 0x07\n\r");
            spi_flash_write_data(&buf1[3][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[3][1], 0x20000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0x70 \t [0x20000] = 0x0B\n\r");

            break;
        }

        case AT25DX011_DEV_INDEX:
        {
            printf_string(UART2, "\n\rAT25Dx011 SPI memory protection features demo.");

            printf_string(UART2, "\n\r1) Unprotecting the whole memory array and doing a full erase");
            spi_flash_chip_erase_forced();  // the whole memory array gets unprotected in this function

            printf_string(UART2, "\n\r2) Retrieving the two bytes at addresses 0x00000 and 0x10000");
            printf_string(UART2, "\n\r   Reading [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " and [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r  (must be [0x00000] = 0xFF and [0x10000] = 0xFF, as the memory has been cleared)");

            printf_string(UART2, "\n\r3) Writing [0x00000]<- 0xE0 and [0x10000]<- 0x0E to the unprotected memory");
            spi_flash_write_data(&buf1[0][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[0][1], 0x10000, 1, &actual_size);
            printf_string(UART2, "\n\r   Reading [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " and [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r  (must be [0x00000] = 0xE0 and [0x10000] = 0x0E)");

            printf_string(UART2, "\n\r4) Enabling memory protection for the whole memory array.");

            spi_flash_configure_memory_protection(AT25DX011_MEM_PROT_ALL);
            printf_string(UART2, "\n\r5) Writing [0x00000]<- 0xD0 and [0x10000]<- 0x0D to the fully protected memory");
            spi_flash_write_data(&buf1[1][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[1][1], 0x10000, 1, &actual_size);
            printf_string(UART2, "\n\r   Reading [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " and [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r  (must be [0x00000] = 0xE0 and [0x10000] = 0x0E), the old values)");

            printf_string(UART2, "\n\r6) Unprotecting the whole memory array and doing a full erase");
            spi_flash_chip_erase_forced();  // the whole memory array gets unprotected in this function
            break;
        }

        case P25Q10U_DEV_INDEX:
        {
            printf_string(UART2, "\n\rP25Q10U SPI memory protection features demo.\n\r");

            // 1. Unprotected memory
            printf_string(UART2, "\n\r1) Unprotected memory test\n\r");
            printf_string(UART2, "\tPerforming a full erase...\n\r");
            spi_flash_chip_erase_forced();  // the whole memory array gets unprotected in this function

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x10000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xFF \t [0x10000] = 0xFF\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xE0 \t [0x10000] = 0x0E\n\r");
            spi_flash_write_data(&buf1[0][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[0][1], 0x10000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x10000] = 0x0E\n\r");

            // 2. Full protected memory
            printf_string(UART2, "\n\r2) Full protected memory test\n\r");
            spi_flash_configure_memory_protection(P25Q10U_MEM_PROT_ALL);
            printf_string(UART2, "\tPerforming a full erase...\n\r");
            spi_flash_chip_erase();

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x10000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x10000] = 0x0E\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xD0 \t [0x10000] = 0x0D\n\r");
            spi_flash_write_data(&buf1[1][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[1][1], 0x10000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x10000] = 0x0E\n\r");


            // 3. Lower half protected memory
            printf_string(UART2, "\n\r3) Lower half protected memory test\n\r");
            spi_flash_configure_memory_protection(P25Q10U_MEM_PROT_LOWER_HALF);
            printf_string(UART2, "\tPerforming a Sector Erase at addresses 0x00000 and 0x10000...\n\r");
            spi_flash_block_erase(0, SPI_FLASH_OP_SE);
            spi_flash_block_erase(0x10000, SPI_FLASH_OP_SE);

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x10000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x10000] = 0xFF\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xB0 \t [0x10000] = 0x0B\n\r");
            spi_flash_write_data(&buf1[2][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[2][1], 0x10000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x10000] = 0x0B\n\r");

            // 4. Upper half protected memory
            printf_string(UART2, "\n\r4) Upper half protected memory test\n\r");
            spi_flash_configure_memory_protection(P25Q10U_MEM_PROT_UPPER_HALF);
            printf_string(UART2, "\tPerforming a Sector Erase at addresses 0x00000 and 0x10000...\n\r");
            spi_flash_block_erase(0, SPI_FLASH_OP_SE);
            spi_flash_block_erase(0x10000, SPI_FLASH_OP_SE);

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x10000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xFF \t [0x10000] = 0x0B\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0x70 \t [0x10000] = 0x07\n\r");
            spi_flash_write_data(&buf1[3][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[3][1], 0x10000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x10000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x10000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0x70 \t [0x10000] = 0x0B\n\r");

            break;
        }

        case GD25WD20_DEV_INDEX:
        {
            printf_string(UART2, "\n\rGD25WD20 SPI memory protection features demo.\n\r");

            // 1. Unprotected memory
            printf_string(UART2, "\n\r1) Unprotected memory test\n\r");
            printf_string(UART2, "\tPerforming a full erase...\n\r");
            spi_flash_chip_erase_forced();  // the whole memory array gets unprotected in this function

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x20000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xFF \t [0x20000] = 0xFF\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xE0 \t [0x20000] = 0x0E\n\r");
            spi_flash_write_data(&buf1[0][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[0][1], 0x20000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x20000] = 0x0E\n\r");

            // 2. Full protected memory
            printf_string(UART2, "\n\r2) Full protected memory test\n\r");
            spi_flash_configure_memory_protection(GD25WD20_MEM_PROT_ALL);
            printf_string(UART2, "\tPerforming a full erase...\n\r");
            spi_flash_chip_erase();

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x20000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x20000] = 0x0E\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xD0 \t [0x20000] = 0x0D\n\r");
            spi_flash_write_data(&buf1[1][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[1][1], 0x20000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x20000] = 0x0E\n\r");

            // 3. Lower half protected memory
            printf_string(UART2, "\n\r3) Lower half protected memory test\n\r");
            spi_flash_configure_memory_protection(GD25WD20_MEM_PROT_LOWER_HALF);
            printf_string(UART2, "\tPerforming a Sector Erase at addresses 0x00000 and 0x20000...\n\r");
            spi_flash_block_erase(0, SPI_FLASH_OP_SE);
            spi_flash_block_erase(0x20000, SPI_FLASH_OP_SE);

            printf_string(UART2, "\tRetrieving the two bytes at addresses 0x00000 and 0x20000\n\r");
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x20000] = 0xFF\n\r");

            printf_string(UART2, "\t Write:    [0x00000] = 0xB0 \t [0x20000] = 0x0B\n\r");
            spi_flash_write_data(&buf1[2][0], 0, 1, &actual_size);
            spi_flash_write_data(&buf1[2][1], 0x20000, 1, &actual_size);
            printf_string(UART2, "\t Read:     [0x00000] = 0x");
            spi_flash_read_data(rd_data_spi, 0, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, " \t [0x20000] = 0x");
            spi_flash_read_data(rd_data_spi, 0x20000, 1, &actual_size);
            printf_byte(UART2, rd_data_spi[0]);
            printf_string(UART2, "\n\r\t Expected: [0x00000] = 0xE0 \t [0x20000] = 0x0B\n\r");

            break;
        }
    }
}

/**
 ****************************************************************************************
 * @brief SPI Flash power mode for Macronix test
 ****************************************************************************************
 */
static void print_MX25R_power_mode(void)
{
    uint32_t power_mode;
    // Get the power mode
    spi_flash_get_power_mode(&power_mode);
    printf_string(UART2, "\n\r\n\rMX25R Power Mode: ");
    if ((power_mode & SPI_FLASH_PM_HPM)== SPI_FLASH_PM_HPM)
        printf_string(UART2, " High Performance Mode ");
    else
        printf_string(UART2, " Low Power Mode ");
}

/**
 ****************************************************************************************
 * @brief SPI Flash Read/Write test
 ****************************************************************************************
 */
static void spi_read_write_test(void)
{
    uint32_t write_size = 512; // set this variable to the desired read size
    uint32_t read_size = 256;  // set this variable to the desired read size
    uint32_t actual_size;
    uint32_t i;

    printf_string(UART2, "\r\n\r\n\r\nSPI Flash Erase/Program/Read test...");
    spi_flash_block_erase(0, SPI_FLASH_OP_SE);

    // Program Page (256 bytes)
    printf_string(UART2, "\n\r\n\rPerforming Program Page...");
    spi_flash_page_program(wr_data_spi, 0, 256);
    printf_string(UART2, " Page programmed.");

    // Read SPI Flash first 256 bytes
    printf_string(UART2, "\r\n\r\nReading SPI Flash first 256 bytes...\r\n");
    spi_flash_read_data(rd_data_spi, 0, read_size, &actual_size);
    // Display Results
    for (i = 0; i < read_size; i++)
    {
        printf_byte(UART2, rd_data_spi[i]);
        printf_string(UART2, " ");
    }
    printf_string(UART2, "\r\nBytes Read: 0x");
    printf_byte(UART2, (actual_size >> 8) & 0xFF);
    printf_byte(UART2, (actual_size) & 0xFF);

    printf_string(UART2, "\r\n\r\nPerforming Sector Erase...");
    spi_flash_block_erase(0, SPI_FLASH_OP_SE);
    printf_string(UART2, "Sector erased.");

    // Write data example (512 bytes)
    printf_string(UART2, "\r\n\r\nPerforming 512 byte write...");
    spi_flash_write_data(wr_data_spi, 0, 512, &actual_size);
    printf_string(UART2, "Data written.");

    // Read SPI Flash first 512 bytes
    printf_string(UART2, "\r\n\r\nReading SPI Flash first 512 bytes...");
    spi_flash_read_data(rd_data_spi, 0, write_size, &actual_size);
    // Display Results
    for (i = 0; i < write_size; i++)
    {
        printf_byte(UART2, rd_data_spi[i]);
        printf_string(UART2, " ");
    }
    printf_string(UART2, "\r\nBytes Read: 0x");
    printf_byte(UART2, (actual_size >> 8) & 0xFF);
    printf_byte(UART2, (actual_size) & 0xFF);
}

/**
 ****************************************************************************************
 * @brief SPI Flash Read/Write test
 ****************************************************************************************
 */
static void spi_read_write_test_buffer(void)
{
    uint32_t write_size = 512; // set this variable to the desired read size
    uint32_t read_size = 256;  // set this variable to the desired read size
    uint32_t actual_size;
    uint32_t i;

    printf_string(UART2, "\r\n\r\n\r\nSPI Flash Erase/Program/Read Buffer test...");
    spi_flash_block_erase(0, SPI_FLASH_OP_SE);

    // Program Page (256 bytes)
    printf_string(UART2, "\n\r\n\rPerforming Program Page...");
    spi_flash_page_program_buffer(wr_data_spi, 0, 256);
    printf_string(UART2, " Page programmed.");

    // Read SPI Flash first 256 bytes
    printf_string(UART2, "\r\n\r\nReading SPI Flash first 256 bytes...\r\n");
    spi_flash_read_data_buffer(rd_data_spi, 0, read_size, &actual_size);
    // Display Results
    for (i = 0; i < read_size; i++)
    {
        printf_byte(UART2, rd_data_spi[i]);
        printf_string(UART2, " ");
    }
    printf_string(UART2, "\r\nBytes Read: 0x");
    printf_byte(UART2, (actual_size >> 8) & 0xFF);
    printf_byte(UART2, (actual_size) & 0xFF);

    printf_string(UART2, "\r\n\r\nPerforming Sector Erase...");
    spi_flash_block_erase(0, SPI_FLASH_OP_SE);
    printf_string(UART2, "Sector erased.");

    // Write data example (512 bytes)
    printf_string(UART2, "\r\n\r\nPerforming 512 byte write...");
    spi_flash_write_data_buffer(wr_data_spi, 0, 512, &actual_size);
    printf_string(UART2, "Data written.");

    // Read SPI Flash first 512 bytes
    printf_string(UART2, "\r\n\r\nReading SPI Flash first 512 bytes...");
    spi_flash_read_data_buffer(rd_data_spi, 0, write_size, &actual_size);
    // Display Results
    for (i = 0; i < write_size; i++)
    {
        printf_byte(UART2, rd_data_spi[i]);
        printf_string(UART2, " ");
    }
    printf_string(UART2, "\r\nBytes Read: 0x");
    printf_byte(UART2, (actual_size >> 8) & 0xFF);
    printf_byte(UART2, (actual_size) & 0xFF);
}

#if defined (CFG_SPI_DMA_SUPPORT)
static void spi_read_write_test_dma(void)
{
    uint32_t write_size = 512; // set this variable to the desired read size
    uint32_t read_size = 256;  // set this variable to the desired read size
    uint32_t actual_size;
    uint32_t i;

    printf_string(UART2, "\r\n\r\n\r\nSPI Flash Erase/Program/Read DMA test...");
    spi_flash_block_erase(0, SPI_FLASH_OP_SE);

    // Program Page (256 bytes)
    printf_string(UART2, "\n\r\n\rPerforming Program Page...");
    spi_flash_page_program_dma(wr_data_spi, 0, 256);
    printf_string(UART2, " Page programmed.");

    // Read SPI Flash first 256 bytes
    printf_string(UART2, "\r\n\r\nReading SPI Flash first 256 bytes...\r\n");
    spi_flash_read_data_dma(rd_data_spi, 0, read_size, &actual_size);
    // Display Results
    for (i = 0; i < read_size; i++)
    {
        printf_byte(UART2, rd_data_spi[i]);
        printf_string(UART2, " ");
    }
    printf_string(UART2, "\r\nBytes Read: 0x");
    printf_byte(UART2, (actual_size >> 8) & 0xFF);
    printf_byte(UART2, (actual_size) & 0xFF);

    printf_string(UART2, "\r\n\r\nPerforming Sector Erase...");
    spi_flash_block_erase(0, SPI_FLASH_OP_SE);
    printf_string(UART2, "Sector erased.");

    // Write data example (512 bytes)
    printf_string(UART2, "\r\n\r\nPerforming 512 byte write...");
    spi_flash_write_data_dma(wr_data_spi, 0, 512, &actual_size);
    printf_string(UART2, "Data written.");

    // Read SPI Flash first 512 bytes
    printf_string(UART2, "\r\n\r\nReading SPI Flash first 512 bytes...");
    spi_flash_read_data_dma(rd_data_spi, 0, write_size, &actual_size);
    // Display Results
    for (i = 0; i < write_size; i++)
    {
        printf_byte(UART2, rd_data_spi[i]);
        printf_string(UART2, " ");
    }
    printf_string(UART2, "\r\nBytes Read: 0x");
    printf_byte(UART2, (actual_size >> 8) & 0xFF);
    printf_byte(UART2, (actual_size) & 0xFF);
}
#endif

void app_peri_spi_flash_run(void)
{
    uint16_t man_dev_id;
    uint64_t unique_id;
    uint32_t jedec_id;
    uint32_t actual_size;
    uint32_t i;

    // Configure SPI Flash environment
    spi_flash_configure_env(&spi_flash_cfg);

    // Initialize SPI
    spi_initialize(&spi_cfg);

    // Configure SPI pins
    GPIO_ConfigurePin(SPI_EN_PORT, SPI_EN_PIN, OUTPUT, PID_SPI_EN, true);
    GPIO_ConfigurePin(SPI_CLK_PORT, SPI_CLK_PIN, OUTPUT, PID_SPI_CLK, false);
    GPIO_ConfigurePin(SPI_DO_PORT, SPI_DO_PIN, OUTPUT, PID_SPI_DO, false);
    GPIO_ConfigurePin(SPI_DI_PORT, SPI_DI_PIN, INPUT, PID_SPI_DI, false);


	uint16_t read_size = 256;  // set this variable to the desired read size

	rd_data_spi = ke_malloc(512, KE_MEM_NON_RETENTION);
	wr_data_spi = ke_malloc(512, KE_MEM_NON_RETENTION);
	
	wr_data_spi[0] = 0;

	for (i = 1; i < 512; i++)
	{
		wr_data_spi[i] = wr_data_spi[i-1] + 1;
	}

	printf_string(UART2, "\n\r******************");
	printf_string(UART2, "\n\r* SPI FLASH TEST *");
	printf_string(UART2, "\n\r******************\n\r");

	// Enable FLASH and SPI
	spi_flash_peripheral_init();
	// spi_flash_chip_erase();
	// Read SPI Flash Manufacturer/Device ID
	spi_flash_read_rems_id(&man_dev_id);

	spi_cs_low();

	spi_cs_high();

	// Erase flash
	spi_flash_chip_erase_forced();

	// Read SPI Flash first 256 bytes
	printf_string(UART2, "\n\r\n\rReading SPI Flash first 256 bytes...");
	spi_flash_read_data(rd_data_spi, 0, read_size, &actual_size);
	// Display Results
	for (i = 0; i < read_size ; i++)
	{
		printf_byte(UART2, rd_data_spi[i]);
		printf_string(UART2, " ");
	}
	printf_string(UART2, "\n\r\n\rBytes Read: 0x");
	printf_byte(UART2, (actual_size >> 8) & 0xFF);
	printf_byte(UART2, (actual_size) & 0xFF);
	printf_string(UART2, "\n\r");

	// Read SPI Flash JEDEC ID
	spi_flash_read_jedec_id(&jedec_id);
	printf_string(UART2, "\n\rSPI flash JEDEC ID is ");
	printf_byte(UART2, (jedec_id >> 16) & 0xFF);
	printf_byte(UART2, (jedec_id >> 8) & 0xFF);
	printf_byte(UART2, (jedec_id) & 0xFF);

	switch (dev_id)
	{
		case W25X10CL_DEV_INDEX:
			printf_string(UART2, "\n\rYou are using W25X10 (1-MBit) SPI flash device.");
		break;

		case W25X20CL_DEV_INDEX:
			printf_string(UART2, "\n\rYou are using W25X20 (2-MBit) SPI flash device.");
		break;

		case AT25DX011_DEV_INDEX:
			printf_string(UART2, "\n\rYou are using AT25DF011 or AT25DS011 (1-MBit) SPI flash device.");
		break;

		case MX25V1006E_DEV_INDEX:
			printf_string(UART2, "\n\rYou are using MX25V1006E 1-Mbit SPI flash device.");
		break;

		case MX25R1035F_DEV_INDEX:
			printf_string(UART2, "\n\rYou are using MX25R1035F 1-Mbit SPI flash device.");
		break;

		case MX25R2035F_DEV_INDEX:
			printf_string(UART2, "\n\rYou are using MX25R2035F 2-Mbit SPI flash device.");
		break;

		case P25Q10U_DEV_INDEX:
			printf_string(UART2, "\n\rYou are using P25Q10U 1-Mbit SPI flash device.");
		break;

		case GD25WD20_DEV_INDEX:
			printf_string(UART2, "\n\rYou are using GD25WD20 2-Mbit SPI flash device.");
		break;

		default:
			printf_string(UART2, "\n\rNo flash detected");
		break;
	}


	if ((dev_id == W25X10CL_DEV_INDEX) ||
		(dev_id == W25X20CL_DEV_INDEX) ||
		(dev_id == P25Q10U_DEV_INDEX) ||
		(dev_id == GD25WD20_DEV_INDEX)
		)
	{
		// Read SPI Flash Manufacturer/Device ID
		spi_flash_read_rems_id(&man_dev_id);
		printf_string(UART2, "\n\r\n\rSPI flash Manufacturer/Device ID is ");
		printf_byte(UART2, (man_dev_id >> 8) & 0xFF);
		printf_byte(UART2, (man_dev_id) & 0xFF);

		spi_flash_read_unique_id(&unique_id);
		printf_string(UART2, "\n\r\n\rSPI flash Unique ID Number is ");
		printf_byte(UART2, ((unique_id >> 32) >> 24) & 0xFF);
		printf_byte(UART2, ((unique_id >> 32) >>16) & 0xFF);
		printf_byte(UART2, ((unique_id >> 32) >>8) & 0xFF);
		printf_byte(UART2, (unique_id >> 32) & 0xFF);
		printf_byte(UART2, (unique_id >> 24) & 0xFF);
		printf_byte(UART2, (unique_id >> 16) & 0xFF);
		printf_byte(UART2, (unique_id >> 8) & 0xFF);
		printf_byte(UART2, (unique_id) & 0xFF);
	}

	if ((dev_id == MX25R1035F_DEV_INDEX) ||
		(dev_id == MX25R2035F_DEV_INDEX))
	{
		//---------------- MX25R Low Power Mode Tests -------------------------------

		spi_flash_set_power_mode(SPI_FLASH_PM_LPM);

		print_MX25R_power_mode();

		spi_read_write_test();
		spi_read_write_test_buffer();
#if defined (CFG_SPI_DMA_SUPPORT)
		spi_read_write_test_dma();
#endif

		//---------------- MX25R High Performance Mode Tests -------------------------------

		spi_flash_set_power_mode(SPI_FLASH_PM_HPM);

		print_MX25R_power_mode();

		spi_read_write_test();
		spi_read_write_test_buffer();
#if defined (CFG_SPI_DMA_SUPPORT)
		spi_read_write_test_dma();
#endif
	}
	else
	{
		spi_read_write_test();
		spi_read_write_test_buffer();
#if defined (CFG_SPI_DMA_SUPPORT)
		spi_read_write_test_dma();
#endif

		// SPI FLASH memory protection features
		spi_protection_features_test();
	}
	printf_string(UART2, "\n\rEnd of test\n\r");

	ke_free(wr_data_spi);
	ke_free(rd_data_spi);
	
}
#endif // __PERI_SAMPLE_SPI_FLASH__

#if defined (__PERI_SAMPLE_I2C_EEPROM__)
// i2c_eeprom ----------------------------------------------------------------------------

#define BUFFER_SIZE             (256)
// uint8_t wr_data[BUFFER_SIZE];
uint8_t* wr_data_i2c;

// uint8_t rd_data[BUFFER_SIZE];
uint8_t* rd_data_i2c;

// Select EEPROM characteristics
#define I2C_EEPROM_DEV_SIZE         0x20000               // EEPROM size in bytes
#define I2C_EEPROM_PAGE_SIZE        256                   // EEPROM page size in bytes
#define I2C_SLAVE_ADDRESS           0x50                  // Set slave device address
#define I2C_SPEED_MODE              I2C_SPEED_FAST        // Speed mode: I2C_SPEED_STANDARD (100 kbits/s), I2C_SPEED_FAST (400 kbits/s)
#define I2C_ADDRESS_MODE            I2C_ADDRESSING_7B     // Addressing mode: {I2C_ADDRESSING_7B, I2C_ADDRESSING_10B}
#define I2C_ADDRESS_SIZE            I2C_2BYTES_ADDR       // Address width: {I2C_1BYTE_ADDR, I2C_2BYTES_ADDR, I2C_3BYTES_ADDR}

// Configuration struct for I2C
static const i2c_cfg_t i2c_cfg = {
    .clock_cfg.ss_hcnt = I2C_SS_SCL_HCNT_REG_RESET,
    .clock_cfg.ss_lcnt = I2C_SS_SCL_LCNT_REG_RESET,
    .clock_cfg.fs_hcnt = I2C_FS_SCL_HCNT_REG_RESET,
    .clock_cfg.fs_lcnt = I2C_FS_SCL_LCNT_REG_RESET,
    .restart_en = I2C_RESTART_ENABLE,
    .speed = I2C_SPEED_MODE,
    .mode = I2C_MODE_MASTER,
    .addr_mode = I2C_ADDRESS_MODE,
    .address = I2C_SLAVE_ADDRESS,
    .tx_fifo_level = 1,
    .rx_fifo_level = 1,
};

// Configuration struct for I2C EEPROM
static const i2c_eeprom_cfg_t i2c_eeprom_cfg = {
    .size = I2C_EEPROM_DEV_SIZE,
    .page_size = I2C_EEPROM_PAGE_SIZE,
    .address_size = I2C_ADDRESS_SIZE,
};

/**
 ****************************************************************************************
 * @brief Test write data.
 * @param[in] data              Pointer to the array of bytes to be written
 * @param[in] address           Starting address of the write process
 * @param[in] size              Size of the data to be written
 * @param[in|out] bytes_written Bytes that were actually written (due to memory size limitation)
 ****************************************************************************************
 */
static uint8_t test_write_data(uint8_t *data, uint32_t address, uint32_t size, uint32_t *bytes_written)
{
    printf_string(UART2, "\n\rWriting page to EEPROM (values 0x00-FF)...\n\r");
    i2c_error_code code = i2c_eeprom_write_data(data, address, size, bytes_written);
    if (code == I2C_NO_ERROR)
    {
        printf_string(UART2, "\n\rPage written.\n\r");
        printf_string(UART2, "\n\rBytes written: 0x");
        printf_byte(UART2, ((*bytes_written) >> 16) & 0xFF);
        printf_byte(UART2, ((*bytes_written) >> 8) & 0xFF);
        printf_byte(UART2, (*bytes_written) & 0xFF);
        printf_string(UART2, "\n\r");
    }
    else
    {
        printf_string(UART2, " - Test failed! - I2C Error code: 0x");
        printf_byte(UART2, code & 0xFF);
        printf_string(UART2, "\n\r");
    }
    return (uint8_t)code;
}

/**
 ****************************************************************************************
 * @brief Test write byte.
 * @param[in] address Memory position to write the byte to
 * @param[in] byte    Byte to be written
 ****************************************************************************************
 */
static uint8_t test_write_byte(uint32_t address, uint8_t byte)
{
    printf_string(UART2, "\n\rWrite byte (0x");
    printf_byte(UART2, byte & 0xFF);
    printf_string(UART2, ") @ address ");
    printf_byte_dec(UART2, address & 0xFF);
    printf_string(UART2, " (zero based)...\n\r");
    i2c_error_code code = i2c_eeprom_write_byte(address, byte);
    if (code == I2C_NO_ERROR)
    {
        printf_string(UART2, "\n\rWrite done.\n\r");
    }
    else
    {
        printf_string(UART2, " - Test failed! - I2C Error code: 0x");
        printf_byte(UART2, code & 0xFF);
        printf_string(UART2, "\n\r");
    }
    return (uint8_t)code;
}

/**
 ****************************************************************************************
 * @brief Test read byte.
 * @param[in] address  Memory address to read the byte from
 * @param[in|out] byte Pointer to the read byte
 ****************************************************************************************
 */
static uint8_t test_read_byte(uint32_t address, uint8_t *byte)
{
    i2c_error_code code = i2c_eeprom_read_byte(address, byte);
    printf_string(UART2, "\n\rRead byte @ address ");
    printf_byte_dec(UART2, address & 0xFF);
    printf_string(UART2, ": 0x");
    printf_byte(UART2, (*byte) & 0xFF);
    printf_string(UART2, "\n\r");
    if (code != I2C_NO_ERROR)
    {
        printf_string(UART2, " - Test failed! - I2C Error code: 0x");
        printf_byte(UART2, code & 0xFF);
        printf_string(UART2, "\n\r");
    }
    return (uint8_t)code;
}

/**
 ****************************************************************************************
 * @brief Test read data.
 * @param[in] data           Pointer to the array of bytes to be read
 * @param[in] address        Starting memory address
 * @param[in] size           Size of the data to be read
 * @param[in|out] bytes_read Bytes that were actually read (due to memory size limitation)
 ****************************************************************************************
 */
static uint8_t test_read_data(uint8_t *data, uint32_t address, uint32_t size, uint32_t *bytes_read)
{
    i2c_error_code code = i2c_eeprom_read_data(data, address, size, bytes_read);
    if (code == I2C_NO_ERROR)
    {
        printf_string(UART2, "\n\r");
        // Display Results
        for (uint32_t i = 0 ; i < size ; i++)
        {
            printf_byte(UART2, data[i]);
            printf_string(UART2, " ");
        }
        printf_string(UART2, "\n\r\n\rBytes read: 0x");
        printf_byte(UART2, ((*bytes_read) >> 16) & 0xFF);
        printf_byte(UART2, ((*bytes_read) >> 8) & 0xFF);
        printf_byte(UART2, (*bytes_read) & 0xFF);
        printf_string(UART2, "\n\r");
    }
    else
    {
        printf_string(UART2, " - Test failed! - I2C Error code: 0x");
        printf_byte(UART2, code & 0xFF);
        printf_string(UART2, "\n\r");
    }
    return (uint8_t)code;
}

void app_peri_i2c_eeprom_run(void)
{
    uint8_t byte;
    uint16_t i;
    uint32_t bytes_read = 0;
    uint32_t bytes_written = 0;
    uint16_t read_size = BUFFER_SIZE;  // the desired read size
    uint16_t write_size = BUFFER_SIZE; // the desired write size

	arch_disable_sleep();

	// Configure I2C EEPROM environment
    i2c_eeprom_configure(&i2c_cfg, &i2c_eeprom_cfg);

    // Initialize I2C
    i2c_eeprom_initialize();

    // Configure I2C pin functionality
    GPIO_ConfigurePin(GPIO_PORT_0, GPIO_PIN_8,  INPUT, PID_I2C_SCL, false);
    GPIO_ConfigurePin(GPIO_PORT_0, GPIO_PIN_11, INPUT, PID_I2C_SDA, false);

	rd_data_i2c = ke_malloc(BUFFER_SIZE, KE_MEM_NON_RETENTION);
	wr_data_i2c = ke_malloc(BUFFER_SIZE, KE_MEM_NON_RETENTION);

	/* test start */
	
    // Populate write vector
    for (i = 0 ; i < write_size ; i++)
    {
        wr_data_i2c[i] = i;
    }
    // Reset read vector
    for (i = 0 ; i < read_size ; i++)
    {
        rd_data_i2c[i] = 0;
    }

    printf_string(UART2, "\n\r\n\r************");
    printf_string(UART2, "\n\r* I2C TEST *\n\r");
    printf_string(UART2, "************\n\r");

    // Page Write
    printf_string(UART2, "\n\r*** Test 1 ***\n\r");
    if(test_write_data(wr_data_i2c, 0, write_size, &bytes_written))
    	goto end_of_test;    

    // Page Read
    printf_string(UART2, "\n\r*** Test 2 ***\n\r");
    printf_string(UART2, "\n\rReading EEPROM...\n\r");
    if(test_read_data(rd_data_i2c, 0, read_size, &bytes_read))
    	goto end_of_test;

    // Setting 1 : 0x5A@22 (dec)
    // Write Byte
    printf_string(UART2, "\n\r*** Test 3 ***\n\r");
    if(test_write_byte(22, 0x5A))
    	goto end_of_test;

    // Random Read Byte
    printf_string(UART2, "\n\r*** Test 4 ***\n\r");
    if(test_read_byte(22, &byte))
    	goto end_of_test;

    // Setting 2 : 0x6A@00 (dec)
    // Write Byte
    printf_string(UART2, "\n\r*** Test 5 ***\n\r");
    if(test_write_byte(0, 0x6A))
    	goto end_of_test;

    // Random Read Byte
    printf_string(UART2, "\n\r*** Test 6 ***\n\r");
    if(test_read_byte(0, &byte))
    	goto end_of_test;

    // Setting 3 : 0x7A@255 (dec)
    // Write Byte
    printf_string(UART2, "\n\r*** Test 7 ***\n\r");
    if(test_write_byte(255, 0x7A))
    	goto end_of_test;

    // Random Read Byte
    printf_string(UART2, "\n\r*** Test 8 ***\n\r");
    if(test_read_byte(255, &byte))
    	goto end_of_test;

    // Setting 4 : 0xFF@30 (dec)
    // Write Byte
    printf_string(UART2, "\n\r*** Test 9 ***\n\r");
    if(test_write_byte(30, 0xFF))
    	goto end_of_test;

    // Random Read Byte
    printf_string(UART2, "\n\r*** Test 10 ***\n\r");
    if(test_read_byte(30, &byte))
    	goto end_of_test;

    // Page read for verification
    printf_string(UART2, "\n\r*** Test 11 ***\n\r");
    printf_string(UART2, "\n\rPage Read to verify that new bytes have been written correctly\n\r");
    printf_string(UART2, "--------------------------------------------------------------\n\r");
    if(test_read_data(rd_data_i2c, 0, read_size, &bytes_read))
    	goto end_of_test;

end_of_test:
    i2c_eeprom_release();
    printf_string(UART2, "\n\r");
    printf_string(UART2, "\n\rEnd of test\n\r");

	// revert to GPIO
    GPIO_ConfigurePin(GPIO_PORT_0, GPIO_PIN_8,  OUTPUT, PID_GPIO, false);
    GPIO_ConfigurePin(GPIO_PORT_0, GPIO_PIN_11, OUTPUT, PID_GPIO, false);

	ke_free(wr_data_i2c);
	ke_free(rd_data_i2c);
	arch_set_extended_sleep(false);

}
#endif // __PERI_SAMPLE_I2C_EEPROM__

#if defined (__PERI_SAMPLE_QUAD_DEC__)

#define QUADRATURE_ENCODER_CHY_CONFIGURATION QUAD_DEC_CHYA_NONE_AND_CHYB_NONE
#define QUADRATURE_ENCODER_CHZ_CONFIGURATION QUAD_DEC_CHZA_NONE_AND_CHZB_NONE

#define QUADRATURE_ENCODER_CHX_A_PORT        GPIO_PORT_0
#define QUADRATURE_ENCODER_CHX_A_PIN         GPIO_PIN_8
#define QUADRATURE_ENCODER_CHX_B_PORT        GPIO_PORT_0
#define QUADRATURE_ENCODER_CHX_B_PIN         GPIO_PIN_9
#define QUADRATURE_ENCODER_CHX_CONFIGURATION QUAD_DEC_CHXA_P08_AND_CHXB_P09

#define WKUP_TEST_BUTTON_1_PORT              GPIO_PORT_0
#define WKUP_TEST_BUTTON_1_PIN               GPIO_PIN_11
#define WKUP_TEST_BUTTON_2_PORT              GPIO_PORT_0
#define WKUP_TEST_BUTTON_2_PIN               GPIO_PIN_1

#define QDEC_CLOCK_DIVIDER                   (1)
#define QDEC_EVENTS_COUNT_TO_INT             (1)

uint8_t terminate_quad_test;
uint8_t quad_started = 0;
uint8_t qdec_xcnt;
uint8_t qdec_ycnt;
uint8_t qdec_zcnt;
uint8_t qdec_new_data = false;


app_peri_quad_dec_start_t conf_quad_dec;

void quad_decoder_user_callback_function(int16_t qdec_xcnt_reg, int16_t qdec_ycnt_reg, int16_t qdec_zcnt_reg)
{
    qdec_xcnt = qdec_xcnt_reg;
    qdec_ycnt = qdec_ycnt_reg;
    qdec_zcnt = qdec_zcnt_reg;
    qdec_new_data = true;

	printf_string(UART2, "\n\n\rQuadec ISR report:");
	
	printf_string(UART2, "\n\r DX: ");
	printf_byte(UART2, qdec_xcnt >> 8);
	printf_byte(UART2, qdec_xcnt & 0xFF);
	
	printf_string(UART2, " DY: ");
	printf_byte(UART2, qdec_ycnt >> 8);
	printf_byte(UART2, qdec_ycnt & 0xFF);
	
	printf_string(UART2, " DZ: ");
	printf_byte(UART2, qdec_zcnt >> 8);
	printf_byte(UART2, qdec_zcnt & 0xFF);

    quad_decoder_enable_irq(1);
}

#if 0
/**
 ****************************************************************************************
 * @brief WKUP callback function
 *
 ****************************************************************************************
 */
void wkup_callback_function(void)
{
    if(!GPIO_GetPinStatus(WKUP_TEST_BUTTON_1_PORT, WKUP_TEST_BUTTON_1_PIN))
    {
        terminate_quad_test = true;
    }

    if(!GPIO_GetPinStatus(WKUP_TEST_BUTTON_2_PORT, WKUP_TEST_BUTTON_2_PIN))
    {
        quad_started ^= true;
    }

    wkupct_enable_irq(WKUPCT_PIN_SELECT(WKUP_TEST_BUTTON_1_PORT, WKUP_TEST_BUTTON_1_PIN) ^
                      WKUPCT_PIN_SELECT(WKUP_TEST_BUTTON_2_PORT, WKUP_TEST_BUTTON_2_PIN),
                      WKUPCT_PIN_POLARITY(WKUP_TEST_BUTTON_1_PORT, WKUP_TEST_BUTTON_1_PIN,
                      WKUPCT_PIN_POLARITY_LOW) ^ WKUPCT_PIN_POLARITY(WKUP_TEST_BUTTON_2_PORT,
                      WKUP_TEST_BUTTON_2_PIN, WKUPCT_PIN_POLARITY_LOW), // polarity low
                      1,    // 1 event
                      40);  // debouncing time = 40

    return;
}
#endif

void app_peri_quad_dec_run(void)
{
//	int16_t qdec_xcnt_reg;

    // Configure quadrature encoder pin functionality
    GPIO_ConfigurePin(QUADRATURE_ENCODER_CHX_A_PORT, QUADRATURE_ENCODER_CHX_A_PIN, INPUT_PULLUP, PID_GPIO, true);
    GPIO_ConfigurePin(QUADRATURE_ENCODER_CHX_B_PORT, QUADRATURE_ENCODER_CHX_B_PIN, INPUT_PULLUP, PID_GPIO, true);
    //GPIO_ConfigurePin(WKUP_TEST_BUTTON_1_PORT, WKUP_TEST_BUTTON_1_PIN, INPUT_PULLUP, PID_GPIO, true);
    //GPIO_ConfigurePin(WKUP_TEST_BUTTON_2_PORT, WKUP_TEST_BUTTON_2_PIN, INPUT_PULLUP, PID_GPIO, true);

    QUAD_DEC_INIT_PARAMS_t quad_dec_init_param = {.chx_port_sel = QUADRATURE_ENCODER_CHX_CONFIGURATION,
                                                  .chy_port_sel = QUADRATURE_ENCODER_CHY_CONFIGURATION,
                                                  .chz_port_sel = QUADRATURE_ENCODER_CHZ_CONFIGURATION,
                                                  .qdec_clockdiv = conf_quad_dec.clk_div,
                                                  .qdec_events_count_to_trigger_interrupt = conf_quad_dec.evt_cnt_bef_int,};
    quad_decoder_init(&quad_dec_init_param);
    quad_decoder_register_callback(quad_decoder_user_callback_function);
    quad_decoder_enable_irq(1);

    printf_string(UART2, "Quadrature Decoder initialized and the interrupt enabled!\n\r\n\r");
	
    printf_string(UART2, "if an interrupt occurs, the following message is printed \n\r\n\r");

	printf_string(UART2, " Quadec ISR report:\n\r");
	printf_string(UART2, "   DX:xxxx DY:xxxx DZ:xxxx\n\r\n\r");

	printf_string(UART2, "To release Quadrature Decoder, run [peri quad_dec stop] at DA16200 \n\r");

#if 0
    wkupct_register_callback(wkup_callback_function);
    wkupct_enable_irq(WKUPCT_PIN_SELECT(WKUP_TEST_BUTTON_1_PORT, WKUP_TEST_BUTTON_1_PIN) ^
                      WKUPCT_PIN_SELECT(WKUP_TEST_BUTTON_2_PORT, WKUP_TEST_BUTTON_2_PIN),
                      WKUPCT_PIN_POLARITY(WKUP_TEST_BUTTON_1_PORT, WKUP_TEST_BUTTON_1_PIN,
                      WKUPCT_PIN_POLARITY_LOW) ^ WKUPCT_PIN_POLARITY(WKUP_TEST_BUTTON_2_PORT,
                      WKUP_TEST_BUTTON_2_PIN, WKUPCT_PIN_POLARITY_LOW), // polarity low
                      1,    // 1 event
                      40);  // debouncing time = 40


    quad_started = false;
    terminate_quad_test = false;
    while(terminate_quad_test == false)
    {
        // polling
        if (quad_started)
        {
            qdec_xcnt_reg = quad_decoder_get_x_counter();
            printf_string(UART2, "\n\r Quadec Polling DX: ");
            printf_byte(UART2, qdec_xcnt_reg >> 8);
            printf_byte(UART2, qdec_xcnt_reg & 0xFF);
        }

        // interrupt triggered
        if (qdec_new_data == true)
        {
            qdec_new_data = false;

            printf_string(UART2, "\n\n\rQuadec ISR report:");

            printf_string(UART2, "\n\r DX: ");
            printf_byte(UART2, qdec_xcnt >> 8);
            printf_byte(UART2, qdec_xcnt & 0xFF);

            printf_string(UART2, " DY: ");
            printf_byte(UART2, qdec_ycnt >> 8);
            printf_byte(UART2, qdec_ycnt & 0xFF);

            printf_string(UART2, " DZ: ");
            printf_byte(UART2, qdec_zcnt >> 8);
            printf_byte(UART2, qdec_zcnt & 0xFF);
        }
    }
    printf_string(UART2, "\n\r Quadrature Decoder Test terminated!");
    printf_string(UART2, "\n\rEnd of test\n\r");
#endif
}


void app_peri_quad_dec_stop(void)
{
	quad_decoder_release();
	
    GPIO_ConfigurePin(QUADRATURE_ENCODER_CHX_A_PORT, QUADRATURE_ENCODER_CHX_A_PIN, OUTPUT, PID_GPIO, false);
    GPIO_ConfigurePin(QUADRATURE_ENCODER_CHX_B_PORT, QUADRATURE_ENCODER_CHX_B_PIN, OUTPUT, PID_GPIO, false);

	printf_string(UART2, "Quadrature Decoder released! \n\r");
}

#endif // __PERI_SAMPLE_QUAD_DEC__

