/**
 ****************************************************************************************
 *
 * @file ext_host_ble_aux_task.c
 *
 * @brief Ext Host BLE Auxiliary Functions Service Task implementation.
 *
 * Copyright (C) 2016. Dialog Semiconductor Ltd, unpublished work. This computer
 * program includes Confidential, Proprietary Information and is a Trade Secret of
 * Dialog Semiconductor Ltd.  All use, disclosure, and/or reproduction is prohibited
 * unless authorized in writing. All Rights Reserved.
 *
 * <bluetooth.support@diasemi.com> and contributors.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "ext_host_ble_aux_task.h"

#include "rf_531.h"
#include "llc.h"
#include "gattm.h"
#include "gapc.h"
#include "gpio.h"
#include "systick.h"
#include "uart.h"
#include "uart_utils.h"

#include "peri_test_function.h"

#if defined (CFG_PRINTF)
#include "arch_console.h"
#endif

#if defined (__DA14531_UART_DISABLE_AT_WIFI_SLEEP__)
#include "user_periph_setup.h"
#endif

#include "app_version.h"

/*
 * DEFINES
 ****************************************************************************************
 */
#define MAX_ECHO_TO_EXTERNAL_HOST_SIZE_IN_BYTES (500)


/*
 * VARIABLES DEFINITIONS
 ****************************************************************************************
 */

//app_gtl_com_err_ind_send() related variables
extern uint8_t gtl_com_err_first_invalid_initiator;
extern enum GTL_STATES_RX gtl_com_err_invalid_header_gtl_state;
extern enum GTL_STATES_RX gtl_com_err_first_invalid_initiator_gtl_state;

//ext_host_ble_aux_task_handler() related variables
uint16_t custom_gtl_over_i2c_param_max_len;
extern uint16_t i2c_timeout;
extern uint8_t gtl_com_err_ind_enabled;

//app_dev_reset_ind_send() related variables
//extern char reset_detection_magic_word[RESET_DETECTION_MAGIC_WORD_MAX_LENGTH] __attribute__( ( section( "NoInit"),zero_init) ) ;
//extern char reset_reason_magic_word[RESET_REASON_MAGIC_WORD_MAX_LENGTH] __attribute__( ( section( "NoInit"),zero_init) ) ;
extern char reset_dump[RESET_DUMP_LENGTH_IN_BYTES];
extern struct gtl_kemsghdr gtl_com_err_invalid_header;

// gtl_log_get_last_messages related variables
uint16_t gtl_log_head;
uint16_t gtl_log_tail;
//uint8_t gtl_log_buf[GTL_LOG_MAX_ENTRIES_COUNT][GTL_LOG_MAX_ENTRY_LENGTH];
//message_metadata_origin_t message_metadata_origin[GTL_LOG_MAX_ENTRIES_COUNT];

bool stats_enabled;
uint16_t stats_interval;
extern struct i2c_env_tag i2c_env;

// demo purpose only
//uint8_t g_app_gas_leak_status = SENSOR_EVT_GAS_LEAK_NOT_OCCURRED;
uint8_t g_app_gas_leak_sensor_value = 0;
#ifdef IOT_SENSOR_LOW_POWER_MODE
uint8_t is_gas_leak_happened;
#if defined (__DA14531_UART_DISABLE_AT_WIFI_SLEEP__)
uint8_t is_wifi_in_sleep;
#endif
#endif

extern void platform_reset_func(uint32_t error);

//uint8_t gtl_log_last_messages_buffer[GTL_LOG_LAST_MESSAGES_COUNT][GTL_LOG_HEADER_LENGTH + 1];

uint32_t dbg_counter_ble_rx_counter;

#ifdef __PERI_GPIO_CONTROL__
#if defined (CFG_WLCSP_PACKAGE)
#define MAX_GPIO_PINS (GPIO_PIN_5 + 1)
#else
#define MAX_GPIO_PINS (GPIO_PIN_11 + 1)
#endif
/*
**  status(0 or 1) which is set gpio pin.
**  control: true means that the pin will be controlled to the status, but we skip if it is false.
**  When config_data->active is 0 or 1 then we set control to true;
**    but it is 0xff then we change the control to 0 (which means skipping initialisation)
**  There is no port info due to DA14531(in DA16600) has only the GPIO_PORT_0
 */
typedef struct {
    bool status;
    bool control;
    #if DEVELOPMENT_DEBUG
    bool reserved;
    #endif
    GPIO_PUPD mode;
} user_gpio_ctrl_t;

user_gpio_ctrl_t gpio_pin_init[MAX_GPIO_PINS] __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
#endif

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
 */

/**
 * @brief todo
 */
void ext_host_ble_aux_task_init(void)
{
    //custom_gtl_over_i2c_param_max_len = CUSTOM_GTL_OVER_I2C_PARAM_LEN_MAX_VALID;  
    // ke_timer_set(APP_SENSOR_RD_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_SENSOR_RD_INTERVAL);
}


/**
 * @brief Retrieve the maximun length set for the custom_gtl_over_i2c_param_max_len variable
 */
uint16_t get_custom_gtl_over_i2c_param_max_len(void)
{
    return custom_gtl_over_i2c_param_max_len;	  
}


/**
 ****************************************************************************************
 * @brief The function which triggers the generation of a random number by the BLE stack
 * @param[in] size The length -in bytes- of the random number
 * @return void
 ****************************************************************************************
 */
void gen_rand(uint8_t size)
{
    int random_word;           
    app_gen_rand_rsp_t * req = (app_gen_rand_rsp_t*)ke_msg_alloc(APP_GEN_RAND_RSP, TASK_GTL, TASK_EXT_HOST_BLE_AUX, (sizeof(app_gen_rand_rsp_t) + size));

    req->status = CO_ERROR_NO_ERROR;
    req->size = size;
          
    for (int i=0; i < size ; i++)
    {
        if (i % 4 == 0)
        {
            random_word = co_rand_word();
        }
        req->rand[i] = random_word & 0xFF;
        random_word = random_word>>8;
    }   
    ke_msg_send(req);   
}


/**
 ****************************************************************************************
 * @brief The function which sends the echo message to the external host.
 * @param[in] data  The incoming message.
 * @param[in] size  The size of the incoming message.
 * @return void
 ****************************************************************************************
 */
void echo_to_external_host(uint8_t *data, uint16_t size)
{
    uint16_t trimmmed_size = size;

    if (size > MAX_ECHO_TO_EXTERNAL_HOST_SIZE_IN_BYTES)
    {
        trimmmed_size = MAX_ECHO_TO_EXTERNAL_HOST_SIZE_IN_BYTES;
    }
        
    void * req = (void*)ke_msg_alloc(APP_ECHO, TASK_GTL, TASK_EXT_HOST_BLE_AUX, trimmmed_size);             
    memcpy(req, data, trimmmed_size);
    ke_msg_send(req);   
}


#if 0
/**
 ****************************************************************************************
 * @brief The function which prepares and sends the response to inform about the status
 * change of the BLE application (APP_STATUS_IND), e.g: Ready, Advertise, Connected...
 * @param[in] status  An enumerator describing the status.
 * @return void
 ****************************************************************************************
 */
void get_status(app_status_t status)
{
    app_status_ind_t * req = (app_status_ind_t*)ke_msg_alloc(APP_STATUS_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_status_ind_t));
    req->status  = status;    
    ke_msg_send(req);   
}


/**
 ****************************************************************************************
 * @brief The function which, upon reception of the APP_SET_TXPOWER sets the TX level
 * of DA14531, and responds to the external host with the message APP_SET_TXPOWER_CFM
 * message
 * @param[in] The transmit output power level from -18dBm up to 3dBm
 * @return void
 ****************************************************************************************
 */
void set_txpower(uint8_t set_tx_power_variable)
{
	app_set_tx_power_cfm_t * req = (app_set_tx_power_cfm_t*)ke_msg_alloc(APP_SET_TXPOWER_CFM, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_set_tx_power_cfm_t));
	
	if((set_tx_power_variable >= RF_TX_PWR_LVL_MINUS_18d0)&&
		(set_tx_power_variable <= RF_TX_PWR_LVL_PLUS_3d1))
	{
		rf_pa_pwr_set((rf_tx_pwr_lvl_t)set_tx_power_variable);
		req->status = APP_NO_ERROR;
	}
	else
		req->status = APP_ERROR_INVALID_PARAMS;
	
    ke_msg_send(req);
}


/**
 ****************************************************************************************
 * @brief The function which, upon reception of the APP_SET_REG_VALUE, sets the value of
 * the designated register and responds to the external host with the message
 * APP_SET_REG_VALUE_CFM message
 * @param[in] address:  The address of the target register
 * @param[in]    data:  The data to write
 * @param[in]    size:  The size of the target register (count of bits: 8,16 or 32)
 * @return void
 * @note            Extra care must be taken to the address selected to write data. This 
 *                  should be a reserved space that is not used by the application.
 ****************************************************************************************
 */
void set_reg_value(uint32_t address, uint32_t data, uint8_t size)
{
    app_set_reg_value_cfm_t * req = (app_set_reg_value_cfm_t*)ke_msg_alloc(APP_SET_REG_VALUE_CFM, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_set_reg_value_cfm_t));
   
    switch (size)
    {
        case 8:
            SetWord8(address, data);
            req->status = APP_NO_ERROR;
            break;
        
        case 16:
            SetWord16(address, data);
            req->status = APP_NO_ERROR;
            break;
        
        case 32:
            SetWord32(address, data);
            req->status = APP_NO_ERROR;
            break;
        
        default:
            req->status = APP_ERROR_INVALID_SIZE;
            break;
    }

    ke_msg_send(req);   
}


/**
 ****************************************************************************************
 * @brief The function which, upon reception of the APP_GET_REG_VALUE, responds to the
 *        external host with the APP_GET_REG_VALUE_RSP message, which includes the value
 *        of ther designated register
 * @param[in] address:  The address of the register to read.
 * @param[in] size:     The size of the register (count of bits: 8,16 or 32).
 * @return void
 ****************************************************************************************
 */
void get_reg_value(uint32_t address, uint8_t size)
{
    app_get_reg_value_rsp_t * req = (app_get_reg_value_rsp_t*)ke_msg_alloc(APP_GET_REG_VALUE_RSP, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_get_reg_value_rsp_t));
   
    req->address = address;
       
    switch (size)
    {
        case 8:
            req->data = GetWord8(address);
            req->size = 8;
            req->status = APP_NO_ERROR;
            break;
        
        case 16:
            req->data = GetWord16(address);
            req->size = 16;
            req->status = APP_NO_ERROR;
            break;        
        
        case 32:
            req->data = GetWord32(address);
            req->size = 32;
            req->status = APP_NO_ERROR;
            break;         
        
        default:
            req->status = APP_ERROR_INVALID_SIZE;
            break;
    }
    ke_msg_send(req);
}
// /**
//  ****************************************************************************************
//  * @brief   The external host sends the APP_SVC_CHANGED_CFG_CMD to set the Client Characteristic
//             Configuration descriptor value of the Service Changed characteristic. This allows enabling or
//             disabling sending of notifications and indications for the Service Changed characteristic.
//  * @param[in] address: 
//  * @return void
//  ****************************************************************************************
//  */
// void send_svc_changed_cfg_cfm(custom_command_status_t status)
// {
//     app_svc_changed_cfg_cfm_t * req = (app_svc_changed_cfg_cfm_t*)ke_msg_alloc(APP_SVC_CHANGED_CFG_CFM, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_svc_changed_cfg_cfm_t));
//     req->status = status;
//     ke_msg_send(req);   
// }


/**
 ****************************************************************************************
 * @brief The callback function for the timer used for the periodic transmission of
 *        statistics
 * @return void
 ****************************************************************************************
 */
void stats_config_timer_callback(void)
{      
    if (stats_enabled)
    {
        ke_timer_set(APP_STATS_TIMER_ID, TASK_EXT_HOST_BLE_AUX, stats_interval);          
        stats_ind_send();
    }         
}


/**
 ****************************************************************************************
 * @brief The callback function for the heartbeat timer
 * @return void
 ****************************************************************************************
 */
void heartbeat_timer_callback(void)
{
    ke_timer_set(APP_HEARTBEAT_TIMER_ID, TASK_EXT_HOST_BLE_AUX, HEARTBEAT_TIMER_INTERVAL/10);
}
#endif

// demo purpose
void sensor_read_timer_callback()
{
	ke_timer_set(APP_GAS_LEAK_SENSOR_RD_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_GAS_LEAK_SENSOR_RD_INTERVAL);
}


#if 0
/**
 ****************************************************************************************
 * @brief Configures the stats (enable/disable sending and at which interval).
 * @param[in] enable            Enable the statistics.
 * @param[in] interval          Interval to send the statistics.
 * @param[in] reset_counters    Clear the struct holding statistics info.
 * @return void
 ****************************************************************************************
 */
void stats_config (bool enable, uint16_t interval, bool reset_counters)
{
    if (interval < APP_STATS_CONFIG_CMD_INTERVAL_MIN)
    {
        interval = APP_STATS_CONFIG_CMD_INTERVAL_MIN;    
    }
    else if (interval > APP_STATS_CONFIG_CMD_INTERVAL_MAX)
    {
        interval = APP_STATS_CONFIG_CMD_INTERVAL_MAX;    
    }
   
    stats_enabled = enable; 
    stats_interval = interval;
#if BLE_METRICS
    if (reset_counters == true)
    {
        metrics.rx_pkt = 0;
        metrics.rx_err = 0;
        metrics.rx_err_crc = 0;
        metrics.rx_err_sync = 0;
        metrics.rx_rssi = 0; //last_rssi = 0;
    }
#else //BLE_METRICS
    //#warning "TODO: ble_metrics reporting"
#endif //BLE_METRICS
    
    if (enable == true)
    {
        ke_timer_set(APP_STATS_TIMER_ID, TASK_EXT_HOST_BLE_AUX, stats_interval);
    }
    else
    {
        ke_timer_clear(APP_STATS_TIMER_ID, TASK_EXT_HOST_BLE_AUX);            
    }
}


/**
 ****************************************************************************************
 * @brief The function which sends the message APP_STATS_IND to the external host,
 *        in order to provide statistics
 * @return void
 * @note    rx_packets : Number of received packets in current connection
 *          rx_error : Number of received error packets
 *          rssi : Last Received Signal Strength
 ****************************************************************************************
 */
void stats_ind_send(void)
{
    app_stats_ind_t * req = (app_stats_ind_t*)ke_msg_alloc(APP_STATS_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_stats_ind_t));

#if BLE_METRICS
    req->rx_packets = metrics.rx_pkt;
    req->rx_errors_all = metrics.rx_err;
    req->rx_errors_crc = metrics.rx_err_crc;
    req->rx_errors_sync = metrics.rx_err_sync;
    req->rssi = metrics.rx_rssi;
#else //BLE_METRICS
    //#warning "TODO: stats_ind_send replace with real data"
#endif //BLE_METRICS
    ke_msg_send(req);
}


/**
 * @brief The function which sends the message APP_DEV_RESET_IND to the external host,
 *        in order to provide information on the reason for the last abnormal reset.
 */
void app_dev_reset_ind_send(void)
{      
    app_dev_reset_ind_t * req = (app_dev_reset_ind_t*)ke_msg_alloc(APP_DEV_RESET_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_dev_reset_ind_t));
    
    if (strcmp(reset_reason_magic_word, RESET_SOURCE_NMI_MAGIC_WORD) == 0)
    {
        req->reason = DEV_RESET_REASON_WATCHDOG_TIMER;
        memcpy(req->dump, reset_dump, RESET_DUMP_LENGTH_IN_BYTES);
        memset(reset_dump, 0x00, RESET_DUMP_LENGTH_IN_BYTES);        
    }
    else if (strcmp(reset_reason_magic_word, RESET_SOURCE_HARDFAULT_MAGIC_WORD) == 0) 
    {
        req->reason = DEV_RESET_REASON_HARD_FAULT;
        memcpy(req->dump, reset_dump, RESET_DUMP_LENGTH_IN_BYTES);
        memset(reset_dump, 0x00, RESET_DUMP_LENGTH_IN_BYTES);
    }           
    else if (strcmp(reset_reason_magic_word, RESET_SOURCE_PLATFORM_MAGIC_WORD) == 0) 
    {
        #define PLATFORM_RESET_MESSAGE_STRING ("Platform reset")        
        req->reason = DEV_RESET_REASON_MEMORY_EXHAUSTED;
        memcpy(req->dump, PLATFORM_RESET_MESSAGE_STRING, strlen(PLATFORM_RESET_MESSAGE_STRING));
    }           
    else    
    {
        req->reason = DEV_RESET_REASON_UNKNOWN;
        ASSERT_WARNING(0);
    }  
    
    memset(reset_detection_magic_word, 0x00, RESET_DETECTION_MAGIC_WORD_MAX_LENGTH);
    memset(reset_reason_magic_word, 0x00, RESET_REASON_MAGIC_WORD_MAX_LENGTH);   
    
    ke_msg_send(req);
}


/**
 * @brief The function which sends the message APP_MTU_CHANGED_IND to the external host,
 *        when the MTU changes, in order to provide the new value of the MTU.
 */
void app_mtu_changed_ind_send(uint16_t mtu)
{
    app_mtu_changed_ind_t * req = (app_mtu_changed_ind_t*)ke_msg_alloc(APP_MTU_CHANGED_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_mtu_changed_ind_t));
    req->mtu_size = mtu;
    ke_msg_send(req);
}

#endif

/**
 ****************************************************************************************
 * @brief Sends and indication with the BLE application fw version, in response to the
 *        APP_GET_FW_VERSION command
 * @return void
 ****************************************************************************************
 */
void app_fw_version_ind_send(void)
{
    app_fw_version_ind_t *req = (app_fw_version_ind_t*)ke_msg_alloc(APP_FW_VERSION_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_fw_version_ind_t));
    memcpy(req->app_fw_version, &SDK_VERSION, strlen(SDK_VERSION));
    ke_msg_send(req);   
}

#if defined (__PERI_SAMPLE_TIMER0_GEN__) || defined (__PERI_SAMPLE_TIMER0_BUZ__) || defined (__PERI_SAMPLE_TIMER2_PWM__)
extern tim0_2_clk_div_config_t clk_div_config;
#endif

// blinky -------------------------------------------------------------------------------
#if defined (__PERI_SAMPLE_BLINKY__)
extern GPIO_PIN blinky_gpio_pin;
extern GPIO_PORT blinky_gpio_port;
extern uint8_t blinky_blink_cnt;
void app_peri_blinky_start_ind_send(app_peri_blinky_start_t* config_data)
{
	ke_timer_set(APP_PERI_BLINKY_RUN_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_PERI_SAMPLE_RUN_AFTER);

	blinky_gpio_port = (GPIO_PORT)config_data->gpio_port;
	blinky_gpio_pin = (GPIO_PIN)config_data->gpio_pin;
	blinky_blink_cnt = config_data->blink_cnt;

    app_peri_blinky_start_ind_t *req = (app_peri_blinky_start_ind_t*)ke_msg_alloc(APP_PERI_BLINKY_START_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_blinky_start_ind_t));
    req->result_code = 0;
    app_peri_blinky_run_start();
    ke_msg_send(req);
}
#endif // __PERI_SAMPLE_BLINKY__

// systick -------------------------------------------------------------------------------
#if defined (__PERI_SAMPLE_SYSTICK__)
extern GPIO_PORT systick_gpio_port;
extern GPIO_PIN systick_gpio_pin;
extern uint32_t systick_period_us;

void app_peri_systick_start_ind_send(app_peri_systick_start_t* config_data)
{
	systick_gpio_port = (GPIO_PORT)config_data->gpio_port;
	systick_gpio_pin = (GPIO_PIN)config_data->gpio_pin;
	systick_period_us = (uint32_t)config_data->period_us;

	arch_disable_sleep();

	ke_timer_set(APP_PERI_SYSTICK_RUN_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_PERI_SAMPLE_RUN_AFTER);		

    app_peri_systick_start_ind_t *req = (app_peri_systick_start_ind_t*)ke_msg_alloc(APP_PERI_SYSTICK_START_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_systick_start_ind_t));
    req->result_code = 0;
    ke_msg_send(req);
}

void app_peri_systick_stop_ind_send(void)
{
	systick_stop();
    app_peri_systick_stop_ind_t *req = (app_peri_systick_stop_ind_t*)ke_msg_alloc(APP_PERI_SYSTICK_STOP_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_systick_stop_ind_t));
    req->result_code = 0;
    ke_msg_send(req);
	
	arch_set_extended_sleep(false);
}
#endif // __PERI_SAMPLE_SYSTICK__

// timer0_gen ----------------------------------------------------------------------------
#if defined (__PERI_SAMPLE_TIMER0_GEN__)
extern app_peri_timer0_gen_start_t config_test_data;
void app_peri_timer0_gen_start_ind_send(app_peri_timer0_gen_start_t* config_data)
{
	ke_timer_set(APP_PERI_TIMER0_GEN_RUN_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_PERI_SAMPLE_RUN_AFTER);

	arch_disable_sleep();
	memcpy((void*)&config_test_data, (void*)config_data, sizeof(app_peri_timer0_gen_start_t));
	clk_div_config.clk_div = (config_test_data.timer0_clk_src == TIM0_CLK_32K) ?
				TIM0_2_CLK_DIV_1 : config_test_data.in_clk_div_factor;

    app_peri_timer0_gen_start_ind_t *req = (app_peri_timer0_gen_start_ind_t*)ke_msg_alloc(APP_PERI_TIMER0_GEN_START_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_timer0_gen_start_ind_t));
    req->result_code = 0;
    ke_msg_send(req);
}
#endif // __PERI_SAMPLE_TIMER0_GEN__

// timer0_buz ----------------------------------------------------------------------------
#if defined (__PERI_SAMPLE_TIMER0_BUZ__)
extern app_peri_timer0_buz_start_t conf_buz;
void app_peri_timer0_buz_start_ind_send(app_peri_timer0_buz_start_t* config_data)
{
	ke_timer_set(APP_PERI_TIMER0_BUZ_RUN_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_PERI_SAMPLE_RUN_AFTER);
	
	arch_disable_sleep();
	memcpy((void*)&conf_buz, (void*)config_data, sizeof(app_peri_timer0_buz_start_t));
	clk_div_config.clk_div = (conf_buz.t0_clk_src == TIM0_CLK_32K) ?
				TIM0_2_CLK_DIV_1 : conf_buz.t0_t2_in_clk_div_factor;

    app_peri_timer0_buz_start_ind_t *req = (app_peri_timer0_buz_start_ind_t*)ke_msg_alloc(APP_PERI_TIMER0_BUZ_START_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_timer0_buz_start_ind_t));
    req->result_code = 0;
    ke_msg_send(req);
}
#endif // __PERI_SAMPLE_TIMER0_BUZ__

// timer2_pwm ----------------------------------------------------------------------------
#if defined (__PERI_SAMPLE_TIMER2_PWM__)
extern app_peri_timer2_pwm_start_t conf_pwm;
extern tim2_config_t config_t2_pwm;
void app_peri_timer2_pwm_start_ind_send(app_peri_timer2_pwm_start_t* config_data)
{
	ke_timer_set(APP_PERI_TIMER2_PWM_RUN_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_PERI_SAMPLE_RUN_AFTER);

	memcpy((void*)&conf_pwm, (void*)config_data, sizeof(app_peri_timer2_pwm_start_t));
	clk_div_config.clk_div = conf_pwm.t0_t2_in_clk_div_factor;
	config_t2_pwm.clk_source = TIM2_CLK_SYS;
	config_t2_pwm.hw_pause = conf_pwm.t2_hw_pause;

    app_peri_timer2_pwm_start_ind_t *req = (app_peri_timer2_pwm_start_ind_t*)ke_msg_alloc(APP_PERI_TIMER2_PWM_START_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_timer2_pwm_start_t));
    req->result_code = 0;
    ke_msg_send(req);
}
#endif // __PERI_SAMPLE_TIMER2_PWM__

// batt_lvl ----------------------------------------------------------------------------
#if defined (__PERI_SAMPLE_BATT_LVL__)
void app_peri_batt_lvl_ind_send(void)
{
	// read batt lvl

    app_peri_batt_lvl_ind_t *req = (app_peri_batt_lvl_ind_t*)ke_msg_alloc(APP_PERI_BATT_LVL_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_batt_lvl_ind_t));

    if (GetBits16(ANA_STATUS_REG, BOOST_SELECTED) != 0x1)
    {
    	req->batt_type = BATT_CR2032;
		req->batt_lvl = battery_get_lvl(BATT_CR2032);
    }
    else
    {
    	req->batt_type = BATT_ALKALINE;
		req->batt_lvl = battery_get_lvl(BATT_ALKALINE);
    }
	
	ke_msg_send(req);
}
#endif // __PERI_SAMPLE_BATT_LVL__

// i2c_eeprom ----------------------------------------------------------------------------
#if defined (__PERI_SAMPLE_I2C_EEPROM__)
void app_peri_i2c_eeprom_start_ind_send(void)
{
	ke_timer_set(APP_PERI_I2C_EEPROM_RUN_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_PERI_SAMPLE_RUN_AFTER);

    app_peri_i2c_eeprom_start_ind_t *req = (app_peri_i2c_eeprom_start_ind_t*)ke_msg_alloc(APP_PERI_I2C_EEPROM_START_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_i2c_eeprom_start_ind_t));
    req->result_code = 0;
    ke_msg_send(req);
}
#endif // __PERI_SAMPLE_I2C_EEPROM__

// spi_flash ----------------------------------------------------------------------------
#if defined (__PERI_SAMPLE_SPI_FLASH__)
void app_peri_spi_flash_start_ind_send(void)
{
	ke_timer_set(APP_PERI_SPI_FLASH_RUN_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_PERI_SAMPLE_RUN_AFTER);

    app_peri_spi_flash_start_ind_t *req = (app_peri_spi_flash_start_ind_t*)ke_msg_alloc(APP_PERI_SPI_FLASH_START_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_spi_flash_start_ind_t));
    req->result_code = 0;
    ke_msg_send(req);
}
#endif // __PERI_SAMPLE_SPI_FLASH__

// quad_dec ----------------------------------------------------------------------------
#if defined (__PERI_SAMPLE_QUAD_DEC__)

extern app_peri_quad_dec_start_t conf_quad_dec;

void app_peri_quad_dec_start_ind_send(app_peri_quad_dec_start_t* conf_param)
{
	memcpy((void*)&conf_quad_dec, (void*)conf_param, sizeof(app_peri_quad_dec_start_t));

	ke_timer_set(APP_PERI_QUAD_DEC_RUN_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_PERI_SAMPLE_RUN_AFTER);

    app_peri_quad_dec_start_ind_t *req = (app_peri_quad_dec_start_ind_t*)ke_msg_alloc(APP_PERI_QUAD_DEC_START_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_quad_dec_start_ind_t));
    req->result_code = 0;
    ke_msg_send(req);
}

void app_peri_quad_dec_stop_ind_send(void)
{
    app_peri_quad_dec_stop_ind_t *req; 

	app_peri_quad_dec_stop();
	
	req = (app_peri_quad_dec_stop_ind_t*)ke_msg_alloc(APP_PERI_QUAD_DEC_STOP_IND, 
    									TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    									sizeof(app_peri_quad_dec_stop_ind_t));
										
    req->result_code = 0;
    ke_msg_send(req);
}

#endif // __PERI_SAMPLE_QUAD_DEC__

// gpio control -------------------------------------------------------------------------------
#if defined (__PERI_GPIO_CONTROL__)
void app_gtl_gpio_init()
{
    for(uint8_t i = 0; i < MAX_GPIO_PINS; i++)
    {
        if(gpio_pin_init[i].control)
            GPIO_ConfigurePin(GPIO_PORT_0, 
              (GPIO_PIN)i, gpio_pin_init[i].mode, PID_GPIO,
			  gpio_pin_init[i].status);
    }
 
}

void app_peri_gpio_set_ind_send(app_peri_gpio_cmd_t* config_data)
{
    app_peri_gpio_ind_t *req = (app_peri_gpio_ind_t*)ke_msg_alloc(APP_PERI_GPIO_SET_IND, 
    					TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    					sizeof(app_peri_gpio_ind_t));
    bool high = config_data->active ? true : false;
    uint8_t pin = config_data->gpio_pin;
    req->result_code = APP_GTL_GPIO_STATUS_INVALID;

    /* Check pin number first */
    if (pin < MAX_GPIO_PINS && config_data->gpio_port == GPIO_PORT_0) {
        if(config_data->active < 0xFF) {
            #if DEVELOPMENT_DEBUG
            if (!gpio_pin_init[pin].reserved) {
                RESERVE_GPIO(EXT_GTL_GPIO, GPIO_PORT_0, (GPIO_PIN)pin, PID_GPIO);
                gpio_pin_init[pin].reserved = true;
            }
            #endif

            GPIO_ConfigurePin(GPIO_PORT_0, (GPIO_PIN)pin, config_data->mode, PID_GPIO, high);
            gpio_pin_init[pin].control = true;
            gpio_pin_init[pin].status = high;
            gpio_pin_init[pin].mode = config_data->mode;
        } else {
            // if active == 0xff then don't control the pin any more.
            gpio_pin_init[pin].control = false;
            gpio_pin_init[pin].status = false;
        }
        req->result_code = APP_GTL_GPIO_STATUS_HANDLED;
    }
    
    ke_msg_send(req);
}

void app_peri_gpio_get_ind_send(app_peri_gpio_cmd_t* config_data)
{
    app_peri_gpio_ind_t *req = (app_peri_gpio_ind_t*)ke_msg_alloc(APP_PERI_GPIO_GET_IND, 
    					TASK_GTL, TASK_EXT_HOST_BLE_AUX, 
    					sizeof(app_peri_gpio_ind_t));

    uint8_t port = config_data->gpio_port;
    uint8_t pin = config_data->gpio_pin;

    if (pin < MAX_GPIO_PINS && port == GPIO_PORT_0) {
        if (gpio_pin_init[pin].control == false)
            req->result_code = APP_GTL_GPIO_STATUS_NOT_IN_USED;
        else
            req->result_code = GPIO_GetPinStatus(GPIO_PORT_0, (GPIO_PIN)pin)?
                                   APP_GTL_GPIO_STATUS_HIGH:APP_GTL_GPIO_STATUS_LOW;
    } else {
        req->result_code = APP_GTL_GPIO_STATUS_INVALID;
    }
    ke_msg_send(req);
}
#endif // __PERI_GPIO_CONTROL__

// ---------------------------------------------------------------------------------------


/**
 ****************************************************************************************
 * @brief Sends and indication with a sensor status attached to ble , in response to the
 *        APP_GAS_LEAK_RD_SENSOR_RSP command
 * @return void
 ****************************************************************************************
 */
void app_gas_leak_sensor_start_cfm_send(void)
{
	ke_timer_set(APP_GAS_LEAK_SENSOR_RD_TIMER_ID, TASK_EXT_HOST_BLE_AUX, APP_GAS_LEAK_SENSOR_RD_INTERVAL); 
	
    app_gas_leak_sensor_start_cfm_t *req = (app_gas_leak_sensor_start_cfm_t*)ke_msg_alloc(APP_GAS_LEAK_SENSOR_START_CFM, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_gas_leak_sensor_start_cfm_t));
	req->status = APP_NO_ERROR;
    ke_msg_send(req);
}


void app_gas_leak_sensor_stop_cfm_send(void)
{
	ke_timer_clear(APP_GAS_LEAK_SENSOR_RD_TIMER_ID, TASK_EXT_HOST_BLE_AUX); 
	
    app_gas_leak_sensor_stop_cfm_t *req = (app_gas_leak_sensor_stop_cfm_t*)ke_msg_alloc(APP_GAS_LEAK_SENSOR_STOP_CFM, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_gas_leak_sensor_stop_cfm_t));
	req->status = APP_NO_ERROR;
    ke_msg_send(req);
}

void app_ble_sw_reset(void)
{
	// reset ble software
    uint16_t tmp;

    // Trigger SW reset
    tmp = GetWord16(SYS_CTRL_REG);
    tmp = (tmp & ~REMAP_ADR0) | 0; // Map ROM at address 0
    tmp |= SW_RESET;
    SetWord16(SYS_CTRL_REG, tmp);
}

#if defined (__TEST_FORCE_EXCEPTION_ON_BLE__) || defined (__RST_EMUL_WHILE_WF_IN_SLEEP__)
void app_ble_force_exception(void)
{
	static const int instr = 0x12345678; /* fake undefined opcode */
	((void(*)(void))&instr)();
}
#endif

/**
 ****************************************************************************************
 * @brief Sends and indication with a sensor status attached to ble , in response to the
 *        APP_GAS_LEAK_RD_SENSOR command
 * @return void
 ****************************************************************************************
 APP_GAS_LEAK_EVT_IND

 
 */
void app_gas_leak_evt_occurred_ind(void)
{
    app_gas_leak_evt_ind_t *req = (app_gas_leak_evt_ind_t*)ke_msg_alloc(APP_GAS_LEAK_EVT_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_gas_leak_evt_ind_t));
    req->evt_status = APP_GAS_LEAK_OCCURRED;
    ke_msg_send(req);   
}



#if 0
/**
 ****************************************************************************************
 * @brief Sends a response with the BLE application debug dump, in response to the
 *        APP_GET_DEBUG_DUMP command from the HOST.
 * @param[in] app_debug_dump_type   Enumerator describing the debug dump selected.
 * @return void
 ****************************************************************************************
 */
void app_get_debug_dump_rsp_send(app_debug_dump_type_t app_debug_dump_type)
{
   app_get_debug_dump_rsp_t *req;
   char *data_source_p = NULL;
   uint16_t size_of_logged_data = 0;
   
   switch (app_debug_dump_type)
   {
        case APP_DEBUG_DUMP_TYPE_LLM_LE_ENV:    //00  
            data_source_p = (char*)&llm_le_env;
            size_of_logged_data = sizeof(struct llm_le_env_tag);
            break;
       
        case APP_DEBUG_DUMP_TYPE_LLC_ENV:       //01
            data_source_p = (char*)&llc_env[0];
            size_of_logged_data = sizeof(struct llc_env_tag);
            break;        
       
        case APP_DEBUG_DUMP_TYPE_GATTM_ENV:     //02
            data_source_p = (char*)&gattm_env;
            size_of_logged_data = sizeof(struct gattm_env_tag);
            break;
       
        case APP_DEBUG_DUMP_TYPE_GATTC_ENV:     //03
            data_source_p = (char*)&gattc_env[0];
            size_of_logged_data = sizeof(struct gattc_env_tag);
            break;
       
        case APP_DEBUG_DUMP_TYPE_GAPM_ENV:      //04
            data_source_p = (char*)&gapm_env;
            size_of_logged_data = sizeof(struct gapm_env_tag);
            break;
       
        case APP_DEBUG_DUMP_TYPE_GAPC_ENV:      //05
            data_source_p = (char*)&gapc_env[0];
            size_of_logged_data = sizeof(struct gapc_env_tag);
            break;
        /*
        case APP_DEBUG_DUMP_TYPE_ATTS_ENV:
            data_source_p = (char*)&atts_env[0];
            size_of_logged_data = sizeof(struct atts_env_tag);
            break;
        */
        case APP_DEBUG_DUMP_TYPE_EM_BLE_CS:     // 07 control structure
            data_source_p = (char*)(0xA000 + EM_BLE_CS_OFFSET);     // EM_BLE_CS_OFFSET = 0x110
            size_of_logged_data = 328;                              // EM_BLE_CS_COUNT * REG_BLE_EM_CS_SIZE, ToDo warning
            break;

        case APP_DEBUG_DUMP_TYPE_EM_BLE_ET:     // 08 exchange table
           data_source_p = (char*)(0xA000 + EM_ET_OFFSET);
           size_of_logged_data = 64;                                // EM_EXCH_TABLE_LEN * REG_COMMON_EM_ET_SIZE
           break;        

        case APP_DEBUG_DUMP_TYPE_RECENT_GTL_COMMANDS:
            data_source_p = (char*)gtl_log_last_messages_buffer;
            size_of_logged_data = gtl_log_get_last_messages((uint8_t*)gtl_log_last_messages_buffer) * (GTL_LOG_HEADER_LENGTH + 1);
            break;

        default:
            ASSERT_WARNING(0);
            return;
   }
    req = (app_get_debug_dump_rsp_t*)ke_msg_alloc(APP_GET_DEBUG_DUMP_RSP, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_get_debug_dump_rsp_t) - 2*sizeof(uint8_t) + size_of_logged_data);
    req->app_debug_dump_type = app_debug_dump_type;
    req->size = size_of_logged_data;
    memcpy(req->app_debug_dump, data_source_p, size_of_logged_data);
    ke_msg_send(req);
}


/**
 ****************************************************************************************
 * @brief Sends a notification to the External Host that a communication error has occured
 * @param[in] app_gtl_com_error_code            todo
 * @param[in] gtl_com_err_cur_invalid_header    todo
 * @param[in] invalid_data_bytes_count          todo
 * @param[in] invalid_data_dump                 todo
 ****************************************************************************************
 */
void app_gtl_com_err_ind_send(app_gtl_com_error_code_t app_gtl_com_error_code, struct gtl_kemsghdr *gtl_com_err_cur_invalid_header, uint16_t invalid_data_bytes_count, uint8_t *invalid_data_dump)
{
    app_gtl_com_err_ind_t *req = NULL;
    uint16_t log_params_length = 0; 
    uint16_t log_dump_total_length = 0; 
    
    switch (app_gtl_com_error_code)
    {  
        case APP_GTL_COM_ERROR_CODE_INVALID_INITIATOR:
            req = (app_gtl_com_err_ind_t*)ke_msg_alloc(APP_GTL_COM_ERR_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_gtl_com_err_ind_t) - 2*sizeof(uint8_t) + 1);
            req->data_dump_bytes_count = 1;        
            req->data_dump[0] = gtl_com_err_first_invalid_initiator;
            req->gtl_state_rx = gtl_com_err_first_invalid_initiator_gtl_state;
            break;
        
        case APP_GTL_COM_ERROR_CODE_INVALID_HEADER:    
            req = (app_gtl_com_err_ind_t*)ke_msg_alloc(APP_GTL_COM_ERR_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_gtl_com_err_ind_t) - 2*sizeof(uint8_t) + sizeof(struct gtl_kemsghdr));
            req->data_dump_bytes_count = sizeof(struct gtl_kemsghdr);
            memcpy(req->data_dump, &gtl_com_err_invalid_header, sizeof(struct gtl_kemsghdr));       
            req->gtl_state_rx = gtl_com_err_invalid_header_gtl_state;        
            break;
        
        case APP_GTL_COM_ERROR_CODE_TIMEOUT:       
            switch (gtl_env.rx_state)
            {
                case GTL_STATE_RX_START:
                    log_dump_total_length = 1;
                    req = (app_gtl_com_err_ind_t*)ke_msg_alloc(APP_GTL_COM_ERR_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_gtl_com_err_ind_t) - 2*sizeof(uint8_t) + log_dump_total_length);
                    req->data_dump_bytes_count = log_dump_total_length;
                    req->data_dump[0] = gtl_env.curr_msg_type;          
                    break;
        
                case GTL_STATE_RX_HDR:
                    log_dump_total_length = 1 + i2c_env.last_rx_snapshot.size - i2c_env.rx.size;
                    if (log_dump_total_length > KE_MSG_HDR_LEN)
                    {
                        ASSERT_WARNING(0);
                    }
                    req = (app_gtl_com_err_ind_t*)ke_msg_alloc(APP_GTL_COM_ERR_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_gtl_com_err_ind_t) - 2*sizeof(uint8_t) + log_dump_total_length);
                    req->data_dump_bytes_count = log_dump_total_length;
                    req->data_dump[0] = gtl_env.curr_msg_type;          
                    memcpy(&req->data_dump[1], (uint8_t *)&gtl_env.curr_hdr_buff[0], log_dump_total_length - 1);                              
                    break;

                case GTL_STATE_RX_PAYL:
                    //volatile struct gtl_env_tag my_dbg_gtl_env = gtl_env;
                    log_params_length = i2c_env.last_rx_snapshot.size - i2c_env.rx.size;
                    if (log_params_length > custom_gtl_over_i2c_param_max_len)
                    {
                        log_params_length = custom_gtl_over_i2c_param_max_len;                        
                    }
                    log_dump_total_length = 1 + KE_MSG_HDR_LEN + log_params_length;
                    req = (app_gtl_com_err_ind_t*)ke_msg_alloc(APP_GTL_COM_ERR_IND, TASK_GTL, TASK_EXT_HOST_BLE_AUX, sizeof(app_gtl_com_err_ind_t) - 2*sizeof(uint8_t) + log_dump_total_length);
                    req->data_dump_bytes_count = log_dump_total_length;
                    req->data_dump[0] = gtl_env.curr_msg_type;
                    memcpy(&req->data_dump[1], (uint8_t *)&gtl_env.curr_hdr_buff[0], KE_MSG_HDR_LEN);
                    memcpy(&req->data_dump[1] + KE_MSG_HDR_LEN, (uint8_t *)&gtl_env.p_msg_rx->param[0], log_params_length);
                    break;   
				
				case GTL_STATE_RX_OUT_OF_SYNC:
					__NOP();
					break;
				
                default:
                    ASSERT_WARNING(0);
                    break;
            }
        
        case APP_GTL_COM_ERROR_CODE_NO_ERROR:
			break;
		
        default:
            ASSERT_WARNING(0);
            break;
    }
    
    if (req != NULL)
    {
        req->app_gtl_com_error_code = app_gtl_com_error_code;
        if (app_gtl_com_error_code == APP_GTL_COM_ERROR_CODE_TIMEOUT)
        {
            req->gtl_state_rx = (enum GTL_STATES_RX) gtl_env.rx_state;
        }
        ke_msg_send(req);
        gtl_com_err_restart_logging();
    }
}

/**
 ****************************************************************************************
 * @brief TODO
 * @param
 ****************************************************************************************
 */
// uint8_t app_get_service_changed_ccc(uint8_t **ind_cfg)
// {
//     return 0;
// }


// uint8_t app_set_service_changed_ccc(uint16_t ind_cfg)
// {
//     return 0;
// }

// uint8_t *service_changed_ccc_p;

#endif
extern void wkup_ext_processor(void);

extern void usDelay2(uint32_t nof_us);

/**
 ****************************************************************************************
 * @brief The handler of the ext_host_ble_aux_task
 ****************************************************************************************
 */
int ext_host_ble_aux_task_handler (ke_msg_id_t const msgid,
                                         void const *param,
                                         ke_task_id_t const dest_id,
                                         ke_task_id_t const src_id)
{    
    enum ke_msg_status_tag ke_msg_status = KE_MSG_CONSUMED;    
    struct ke_msg * msg = ke_param2msg(param);	

#if defined (CFG_PRINTF)
		//arch_printf("ext_host_ble_aux_task_handler\r\n");
		//arch_printf("msgid = %d, msg->dest_id = %d, msg->src_id = %d, dest_id = %d, src_id = %d \r\n", msgid, msg->dest_id, msg->src_id, dest_id, src_id);
#endif

#if 0
    // Send msg from stats_config() function to enable
    if (msgid == APP_STATS_TIMER_ID)
    {
        stats_config_timer_callback();
        return KE_MSG_CONSUMED;
    }
    else if (msgid == APP_HEARTBEAT_TIMER_ID)
    {
        heartbeat_timer_callback();
        return KE_MSG_CONSUMED;
    }
#endif

    if (msgid == APP_GAS_LEAK_SENSOR_RD_TIMER_ID)
    {

#if defined (__RST_EMUL_WHILE_WF_IN_SLEEP__)
			app_ble_force_exception();
#endif

#if defined (CFG_PRINTF)	
			arch_printf(" timer expires (APP_GAS_LEAK_SENSOR_RD_TIMER_ID), re-set ... \r\n");
#endif
			sensor_read_timer_callback();
		
			g_app_gas_leak_sensor_value = (uint16_t)co_rand_word();
#if defined (CFG_PRINTF)			
			arch_printf(" sensor value read = %d \r\n", g_app_gas_leak_sensor_value);
#endif
			
			if ((g_app_gas_leak_sensor_value % 3) == APP_GAS_LEAK_OCCURRED) 
			{
#ifdef IOT_SENSOR_LOW_POWER_MODE
#if defined (CFG_PRINTF)	
				arch_printf("leak occurred !!!!!!!, waking Wi-Fi \r\n");
#endif
				is_gas_leak_happened = 1;

#if defined (__DA14531_UART_DISABLE_AT_WIFI_SLEEP__)
				if (is_wifi_in_sleep)
				{
					gtl_uart_enable();
				}
#endif // __DA14531_UART_DISABLE_AT_WIFI_SLEEP__
				wkup_ext_processor();

				app_gas_leak_evt_occurred_ind();
#if defined (CFG_PRINTF)								
				arch_printf("now gas-leak message is to be sent! \r\n");
#endif


#if defined (__DA14531_UART_DISABLE_AT_WIFI_SLEEP__)
				is_wifi_in_sleep = false;
#endif

#else			
#if defined (CFG_PRINTF)
				arch_printf("leak occurred !!!!!!!, report to gtl host \r\n");	
#endif
				app_gas_leak_evt_occurred_ind();
#endif // IOT_SENSOR_LOW_POWER_MODE				
			} 
			else 
			{
#if defined (CFG_PRINTF)	
				arch_printf("leak NOT occurred. \r\n");
#endif
			}
			return KE_MSG_CONSUMED;
    }        
#if defined (__PERI_SAMPLE_BLINKY__)
	else if (msgid == APP_PERI_BLINKY_RUN_TIMER_ID)
	{
		app_peri_blinky_run();
		return KE_MSG_CONSUMED;
	}
#endif
#if defined (__PERI_SAMPLE_SYSTICK__)
	else if (msgid == APP_PERI_SYSTICK_RUN_TIMER_ID)
	{
		app_peri_systick_run();
		return KE_MSG_CONSUMED;
	}
#endif
#if defined (__PERI_SAMPLE_TIMER0_GEN__)
	else if (msgid == APP_PERI_TIMER0_GEN_RUN_TIMER_ID)
	{
		app_peri_timer0_gen_run();
		return KE_MSG_CONSUMED;
	}
	else if (msgid == APP_PERI_TIMER0_GEN_STOP_TIMER_ID)
	{
		app_peri_timer0_gen_stop();
		return KE_MSG_CONSUMED;
	}
#endif
#if defined (__PERI_SAMPLE_TIMER0_BUZ__)
	else if (msgid == APP_PERI_TIMER0_BUZ_RUN_TIMER_ID)
	{
		app_peri_timer0_buz_run();
		return KE_MSG_CONSUMED;
	}
	else if (msgid == APP_PERI_TIMER0_BUZ_STOP_TIMER_ID)
	{
		app_peri_timer0_buz_stop();
		return KE_MSG_CONSUMED;
	}
#endif
#if defined (__PERI_SAMPLE_TIMER2_PWM__)
	else if (msgid == APP_PERI_TIMER2_PWM_RUN_TIMER_ID)
	{
		app_peri_timer2_pwm_run();
		return KE_MSG_CONSUMED;
	}
#endif
#if defined (__PERI_SAMPLE_I2C_EEPROM__)
	else if (msgid == APP_PERI_I2C_EEPROM_RUN_TIMER_ID)
	{
		app_peri_i2c_eeprom_run();
		return KE_MSG_CONSUMED;
	}
#endif
#if defined (__PERI_SAMPLE_SPI_FLASH__)
	else if (msgid == APP_PERI_SPI_FLASH_RUN_TIMER_ID)
	{
		app_peri_spi_flash_run();
		return KE_MSG_CONSUMED;
	}
#endif
#if defined (__PERI_SAMPLE_QUAD_DEC__)
	else if (msgid == APP_PERI_QUAD_DEC_RUN_TIMER_ID)
	{
		app_peri_quad_dec_run();
		return KE_MSG_CONSUMED;
	}
#endif

//    dbg_counter_ble_rx_counter++;
    
    //msg->dest_id = msg->src_id; 
    msg->src_id = TASK_GTL; 
    
    if (msg->dest_id == TASK_EXT_HOST_BLE_AUX)
    {
        switch (msgid)
        {
#if 0
            case APP_GEN_RAND_REQ:
                gen_rand(((app_gen_rand_req_t*)param)->size);
                break;
                        
            case APP_SET_TXPOWER: // 0xA005
                set_txpower(((app_set_txpower_t*)param)->set_tx_power_variable);
                break;
            
            case APP_SET_REG_VALUE:
                set_reg_value(((app_set_reg_value_t*)param)->address, ((app_set_reg_value_t*)param)->data, ((app_set_reg_value_t*)param)->size);
                break;
            
            case APP_GET_REG_VALUE:
                get_reg_value(((app_get_reg_value_t*)param)->address, ((app_get_reg_value_t*)param)->size);
                break;
            
            case APP_DBG_CONFIG_CMD:
                if ((((app_dbg_config_cmd_t*)param)->operations & APP_DBG_CONFIG_STATS) != 0)
                {
                    stats_config(((app_dbg_config_cmd_t*)param)->stats_enable, ((app_dbg_config_cmd_t*)param)->stats_interval, ((app_dbg_config_cmd_t*)param)->stats_reset_counters);
                } 

                if ((((app_dbg_config_cmd_t*)param)->operations & APP_DBG_CONFIG_MSG_MAX_LEN) != 0)
                {
                    uint16_t custom_gtl_over_i2c_param_max_len_to_set = ((app_dbg_config_cmd_t*)param)->i2c_message_max_len;
                    if (custom_gtl_over_i2c_param_max_len_to_set < CUSTOM_GTL_OVER_I2C_PARAM_LEN_MIN_VALID)
                    {
                        custom_gtl_over_i2c_param_max_len_to_set = CUSTOM_GTL_OVER_I2C_PARAM_LEN_MIN_VALID;
                    }
                    else if (custom_gtl_over_i2c_param_max_len_to_set > CUSTOM_GTL_OVER_I2C_PARAM_LEN_MAX_VALID)
                    {
                        custom_gtl_over_i2c_param_max_len_to_set = CUSTOM_GTL_OVER_I2C_PARAM_LEN_MAX_VALID;
                    }  
                    custom_gtl_over_i2c_param_max_len = custom_gtl_over_i2c_param_max_len_to_set;
                }

                if ((((app_dbg_config_cmd_t*)param)->operations & APP_DBG_CONFIG_I2C_TIMEOUT) != 0)
                {
                    uint16_t custom_gtl_over_i2c_timeout_to_set = ((app_dbg_config_cmd_t*)param)->i2c_timeout;
                    if (custom_gtl_over_i2c_timeout_to_set < I2C_RX_TIMEOUT_MIN)
                    {
                        custom_gtl_over_i2c_timeout_to_set = I2C_RX_TIMEOUT_MIN;
                    }
                    else if (custom_gtl_over_i2c_timeout_to_set > I2C_RX_TIMEOUT_MAX)
                    {
                        custom_gtl_over_i2c_timeout_to_set = I2C_RX_TIMEOUT_MAX;                         
                    }
                    i2c_timeout = custom_gtl_over_i2c_timeout_to_set;
                }
                
                if ((((app_dbg_config_cmd_t*)param)->operations & APP_DBG_CONFIG_GTL_CON_ERR_IND) != 0)
                {
                    gtl_com_err_ind_enabled = ((app_dbg_config_cmd_t*)param)->gtl_com_err_ind_enable;
                    i2c_timeout = ((app_dbg_config_cmd_t*)param)->i2c_timeout;
                }
                break;
#endif
            case APP_ECHO:
                echo_to_external_host((uint8_t *)param, msg->param_len);
                break;
            
            case APP_GET_FW_VERSION:
                app_fw_version_ind_send();
                break;

            case APP_GAS_LEAK_SENSOR_START:
								app_gas_leak_sensor_start_cfm_send();
#if defined (CFG_PRINTF)
								arch_printf("<<< APP_GAS_LEAK_SENSOR_START_CFM \r\n");
#endif
                break;

            case APP_GAS_LEAK_SENSOR_STOP:
								app_gas_leak_sensor_stop_cfm_send();
#if defined (CFG_PRINTF)								
								arch_printf("<<< APP_GAS_LEAK_SENSOR_STOP_CFM \r\n");
#endif
                break;

            case APP_BLE_SW_RESET:
				//printf_string(UART2, ">>> APP_BLE_SW_RESET\n\r");
				//usDelay2(120);
				app_ble_sw_reset();
                break;
			
#if defined (__TEST_FORCE_EXCEPTION_ON_BLE__)
            case APP_BLE_FORCE_EXCEPTION:
				app_ble_force_exception();
                break;
#endif			
						
#ifdef IOT_SENSOR_LOW_POWER_MODE
			case APP_WIFI_READY:
  			break;

#if defined (__DA14531_UART_DISABLE_AT_WIFI_SLEEP__)
			case APP_WIFI_SLEEP:
#if defined (CFG_PRINTF)							
				arch_printf(">>> APP_WIFI_SLEEP \r\n");
#endif
				gtl_uart_disable();
				is_wifi_in_sleep = true;
				
			break;
#endif // __DA14531_UART_DISABLE_AT_WIFI_SLEEP__
#endif // IOT_SENSOR_LOW_POWER_MODE


#if 0
            case APP_GET_DEBUG_DUMP:
                app_get_debug_dump_rsp_send(((app_get_debug_dump_t*)param)->app_debug_dump_type);
                break;
#endif
#if defined (__PERI_SAMPLE_BLINKY__)
            case APP_PERI_BLINKY_START:
                app_peri_blinky_start_ind_send((app_peri_blinky_start_t*)msg->param);				
                break;
#endif

#if defined (__PERI_SAMPLE_SYSTICK__)
            case APP_PERI_SYSTICK_START:
                app_peri_systick_start_ind_send((app_peri_systick_start_t*)msg->param);				
                break;
            case APP_PERI_SYSTICK_STOP:
                app_peri_systick_stop_ind_send();				
                break;
#endif

#if defined (__PERI_SAMPLE_TIMER0_GEN__)
            case APP_PERI_TIMER0_GEN_START:
                app_peri_timer0_gen_start_ind_send((app_peri_timer0_gen_start_t*)msg->param);				
                break;
#endif

#if defined (__PERI_SAMPLE_TIMER0_BUZ__)
            case APP_PERI_TIMER0_BUZ_START:
                app_peri_timer0_buz_start_ind_send((app_peri_timer0_buz_start_t*)msg->param);				
                break;
#endif

#if defined (__PERI_SAMPLE_TIMER2_PWM__)
            case APP_PERI_TIMER2_PWM_START:
                app_peri_timer2_pwm_start_ind_send((app_peri_timer2_pwm_start_t*)msg->param);				
                break;
#endif

#if defined (__PERI_SAMPLE_BATT_LVL__)
            case APP_PERI_GET_BATT_LVL:
                app_peri_batt_lvl_ind_send();				
                break;
#endif

#if defined (__PERI_SAMPLE_I2C_EEPROM__)
            case APP_PERI_I2C_EEPROM_START:
                app_peri_i2c_eeprom_start_ind_send();				
                break;
#endif

#if defined (__PERI_SAMPLE_SPI_FLASH__)
            case APP_PERI_SPI_FLASH_START:
                app_peri_spi_flash_start_ind_send();				
                break;
#endif

#if defined (__PERI_SAMPLE_QUAD_DEC__)
			case APP_PERI_QUAD_DEC_START:
				app_peri_quad_dec_start_ind_send((app_peri_quad_dec_start_t*)msg->param);
				break;
			
			case APP_PERI_QUAD_DEC_STOP:
				app_peri_quad_dec_stop_ind_send();
				break;
#endif

#if defined (__PERI_GPIO_CONTROL__)
            case APP_PERI_GPIO_SET_CMD:
                app_peri_gpio_set_ind_send((app_peri_gpio_cmd_t *)msg->param);			    
                break;

            case APP_PERI_GPIO_GET_CMD:
                app_peri_gpio_get_ind_send((app_peri_gpio_cmd_t *)msg->param);				
                break;
#endif  // __PERI_GPIO_CONTROL__

            // This comand is not supported anymore, done from host on connection confirmation
            // case APP_SVC_CHANGED_CFG_CMD:
            //     if ( (app_set_service_changed_ccc(((app_svc_changed_cfg_cmd_t*)param)->ind_cfg) != 0) &&
            //          (app_get_service_changed_ccc(&service_changed_ccc_p) != 0) )
            //     {
            //         send_svc_changed_cfg_cfm(APP_NO_ERROR); 
            //     }
            //     else
            //     {
            //         send_svc_changed_cfg_cfm(APP_ERROR_INVALID_PARAMS); 
            //     }
            //     break;
        
            default:
                //ASSERT_ERROR(0);
                break;
        }
    }
    else
    {
        ke_msg_status = KE_MSG_NO_FREE;
        ke_task_id_t c_dst = ke_param2msg(param)->dest_id;
        ke_task_id_t c_src = TASK_GTL;
        ke_msg_forward(param, c_dst, c_src); 
    }

#if 0
    // The 0xFF flag denotes whether the command was received or transmitted
    gtl_log_add_entry(GTL_LOG_MESSAGE_METADATA_ORIGIN_EXT_HOST, (uint8_t*)param-8, 8);
#endif
    return (ke_msg_status);
}

#if 0
/**
 * @brief The function which parses the log of the most recent headers of messages.
 */
int8_t gtl_log_add_entry(message_metadata_origin_t message_origin, uint8_t *buf, uint8_t size)
{
	// Will reach GTL_LOG_MAX_ENTRIES_COUNT and cycle to start
    gtl_log_head = (gtl_log_head + 1) % GTL_LOG_MAX_ENTRIES_COUNT;
    if (gtl_log_head == gtl_log_tail)
    {
        // reached limit
        __NOP();
    }  
    memcpy(gtl_log_buf[gtl_log_head], buf, size);
    message_metadata_origin[gtl_log_head] = message_origin;

    return 0;
}
#endif

/*
 * GLOBAL VARIABLES DEFINITION
 ****************************************************************************************
 */

/* Default State handlers definition. */
const struct ke_msg_handler ext_host_ble_aux_default_state[] =
{
    {KE_MSG_DEFAULT_HANDLER,                (ke_msg_func_t)ext_host_ble_aux_task_handler},
};


/* Specifies the message handlers that are common to all states. */
const struct ke_state_handler ext_host_ble_aux_default_handler = KE_STATE_HANDLER(ext_host_ble_aux_default_state);

///Defines the place holder for the states of all the task instances.
ke_state_t ext_host_ble_aux_state[EXT_HOST_BLE_AUX_IDX_MAX] __attribute__((section("retention_mem_area0"),zero_init)); //@RETENTION MEMORY

