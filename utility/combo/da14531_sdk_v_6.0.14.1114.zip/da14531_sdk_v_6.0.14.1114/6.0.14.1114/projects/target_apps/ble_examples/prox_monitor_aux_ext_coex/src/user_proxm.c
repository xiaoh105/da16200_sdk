/**
 ****************************************************************************************
 *
 * @file user_proxm.c
 *
 * @brief Proximity monitor external processor user application source code.
 *
 * Copyright (C) 2012-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup APP
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "rwip_config.h"             // SW configuration
#include "user_periph_setup.h"       // SW configuration
#include "user_proxm.h"
#include "arch_api.h"
#include "user_config.h"
#include "ext_host_ble_aux_task.h"
#include "ext_host_ble_aux.h"

#if (WLAN_COEX_ENABLED)
#include "wlan_coex.h"
#include "lld.h"
#endif

#if defined (CFG_PRINTF)
#include "arch_console.h"
#endif

#if defined (CFG_CTS_EXT_WAKEUP)
#include "user_uart_gtl.h"
#endif

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
*/

/**
 ****************************************************************************************
 * @brief User code initialization function.
 ****************************************************************************************
*/

void user_on_init(void)
{
#if defined (CFG_CTS_EXT_WAKEUP)
	ext_wakeup_enable_custom(UART1_CTSN_PORT, UART1_CTSN_PIN, 0);
#endif

#if (WLAN_COEX_ENABLED)
     wlan_coex_init();
  
     //wlan_coex_prio_criteria_add(BLEMPRIO_SCAN, LLD_ADV_HDL, 0);
     //wlan_coex_prio_criteria_add(BLEMPRIO_ADV, LLD_ADV_HDL, 0);     
     //wlan_coex_prio_criteria_add(BLEMPRIO_CONREQ, LLD_ADV_HDL, 0);
    
     //wlan_coex_prio_criteria_add(BLEMPRIO_LLCP, 0, 0);
     //wlan_coex_prio_criteria_add(BLEMPRIO_DATA, 0, 0);
     wlan_coex_prio_criteria_add(WLAN_COEX_BLE_PRIO_MISSED, 0, 1);
#endif

#if defined (__ANT_CTRL_BY_BTACT__)
	extern void enable_diagnostic(void);
	enable_diagnostic();
#endif
    
    arch_set_sleep_mode(app_default_sleep_mode);
	ext_host_ble_aux_init();
	ext_host_ble_aux_task_init();
#if defined (CFG_PRINTF)	
	arch_printf("user_on_init\r\n");
#endif
}

sleep_mode_t user_validate_sleep(sleep_mode_t sleep_mode)
{
#if (WLAN_COEX_ENABLED)
    wlan_coex_going_to_sleep();
#endif

#if defined (CFG_CTS_EXT_WAKEUP)
	extern bool ext_wake_up_req;
	if (ext_wake_up_req !=0)
	{
	    return mode_active;
	}
	else
#endif
    return sleep_mode;
}

/// @} APP
