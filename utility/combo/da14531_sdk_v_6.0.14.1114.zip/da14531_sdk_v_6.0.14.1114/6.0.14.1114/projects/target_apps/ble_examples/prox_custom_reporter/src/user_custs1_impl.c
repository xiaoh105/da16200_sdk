/**
 ****************************************************************************************
 *
 * @file user_custs1_impl.c
 *
 * @brief Custom1 Server implementation source code.
 *
 * Copyright (C) 2015-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#ifdef CFG_PRF_CUST1
#include "gpio.h"
#include "app_api.h"
#include "app.h"
#include "prf_utils.h"
#include "custs1.h"
#include "custs1_task.h"
#include "user_custs1_def.h"
#include "user_custs1_impl.h"
#include "user_periph_setup.h"
//#include "port_platform.h"
//#include "ke_event.h"
#include "user_callback_config.h"
#include "user_proxr.h"

/*
 * DEFINES
 ****************************************************************************************
 */

typedef struct {
    //uint8_t data[USER_CUSTS1_REPORT_MAX_SIZE];
    uint8_t data[50];
    uint8_t len;
    uint8_t handle;
} user_custs1_rep_node_t;

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

//uint16_t indication_counter   __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
bool custs1_report_ntf_busy   __SECTION_ZERO("retention_mem_area0");   // report notification busy flag

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
 */
void user_custs1_report_to_host(uint8_t handle, uint8_t *data, uint8_t len)
{
    if(custs1_report_ntf_busy) return;

    custs1_report_ntf_busy = true;
    struct custs1_val_ntf_ind_req *req =
               KE_MSG_ALLOC_DYN(CUSTS1_VAL_NTF_REQ,
                                prf_get_task_from_id(TASK_ID_CUSTS1),
                                TASK_APP,
                                custs1_val_ntf_ind_req,
                                len);
    
    req->conidx = conhdl_to_conidx(app_env->conhdl); //app_env->conidx;
    req->handle = handle;
    req->length = len;
    req->notification = true;
    memcpy(req->value, data, len);
    ke_msg_send(req);

    custs1_report_ntf_busy = false;
}

static void user_custs1_wf_cmd_wr_ind_handler(struct custs1_val_write_ind *param)
{
	return;
}

static void user_custs1_val_ntf_cfm(void *msg)
{
    struct custs1_val_ntf_cfm *msg_param = (struct custs1_val_ntf_cfm *)(msg);
    switch (msg_param->handle) {
        default:
            break;
    }
}

static void user_custs1_val_write_ind(void *msg)
{
    struct custs1_val_write_ind *msg_param = (struct custs1_val_write_ind *)msg;
    switch( msg_param->handle)
    {
        case SVC1_IDX_ADC_VAL_1_VAL:
            user_custs1_wf_cmd_wr_ind_handler(msg_param);
            break;

        case SVC1_IDX_ADC_VAL_1_NTF_CFG:
            //user_custs1_val_ntf_cfm(msg_param);
            user_app_custs1_adc_ntf_cfg(*((uint16_t*)&msg_param->value[0]));
            break;

        default:
            break;
    }
}
 
void user_custs1_init(void)
{
    // add something later here. // checkroy
    custs1_report_ntf_busy = false;
}

void user_custs1_handler(ke_msg_id_t const msg_id, void *msg)
{
    switch(msg_id) {
        case CUSTS1_VAL_WRITE_IND:
            user_custs1_val_write_ind(msg);
            break;
        
        case CUSTS1_VAL_NTF_CFM:
            user_custs1_val_ntf_cfm(msg);
            break;
        
        default:
            break;
        
    }
}

/*
 * example, how to call/use, this update the db with the value, Host has to read.
 * user_custs1_value_set_req(SVC1_IDX_WFACT_RES_VAL, (uint8_t *)&val, 2);
 */
void user_custs1_value_set_req(uint8_t handle, uint8_t *data, uint16_t length)
{
    struct custs1_val_set_req *req = KE_MSG_ALLOC_DYN(CUSTS1_VAL_SET_REQ,
                                                      prf_get_task_from_id(TASK_ID_CUSTS1),
                                                      TASK_APP,
                                                      custs1_val_set_req,
                                                      length);

    req->conidx = conhdl_to_conidx(app_env->conhdl);
    req->handle = handle;
    req->length = length;
    memcpy(req->value, data, length);

    ke_msg_send(req);
}

void user_app_adc_report(uint8_t sample)
{
    struct custs1_val_ntf_ind_req *req = KE_MSG_ALLOC_DYN(CUSTS1_VAL_NTF_REQ,
                                                          prf_get_task_from_id(TASK_ID_CUSTS1),
                                                          TASK_APP,
                                                          custs1_val_ntf_ind_req,
                                                          DEF_SVC1_ADC_VAL_1_CHAR_LEN);

    req->conidx = app_env->conidx;
    req->notification = true;
    req->handle = SVC1_IDX_ADC_VAL_1_VAL;
    req->length = DEF_SVC1_ADC_VAL_1_CHAR_LEN;
    memcpy(req->value, &sample, DEF_SVC1_ADC_VAL_1_CHAR_LEN);

    ke_msg_send(req);
}
#endif
